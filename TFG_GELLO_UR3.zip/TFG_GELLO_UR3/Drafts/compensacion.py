from dynamixel_sdk import PortHandler, PacketHandler
import math, time, signal, sys

PORT = "/dev/ttyUSB2"     # el brazo de motores 8-13 (ajusta si bailó el puerto)
DXL_ID = 11               # codo
BAUD = 57600

ADDR_OPERATING_MODE   = 11
ADDR_TORQUE_ENABLE    = 64
ADDR_GOAL_CURRENT     = 102
ADDR_PRESENT_POSITION = 132
ADDR_PRESENT_CURRENT  = 126
TICKS = 4096

ph = PortHandler(PORT); pk = PacketHandler(2.0)
ph.openPort(); ph.setBaudRate(BAUD)

pk.write1ByteTxRx(ph, DXL_ID, ADDR_TORQUE_ENABLE, 0)
pk.write1ByteTxRx(ph, DXL_ID, ADDR_OPERATING_MODE, 0)   # modo corriente
pk.write1ByteTxRx(ph, DXL_ID, ADDR_TORQUE_ENABLE, 1)

def set_corriente(val):
    val = max(-200, min(200, int(val)))
    pk.write2ByteTxRx(ph, DXL_ID, ADDR_GOAL_CURRENT, val & 0xFFFF)

def leer_angulo():
    pos, _, _ = pk.read4ByteTxRx(ph, DXL_ID, ADDR_PRESENT_POSITION)
    return (pos % TICKS) / TICKS * 2 * math.pi

def leer_corriente():
    cur, _, _ = pk.read2ByteTxRx(ph, DXL_ID, ADDR_PRESENT_CURRENT)
    if cur > 32767: cur -= 65536
    return cur

def apagar(*_):
    try:
        set_corriente(0)
        time.sleep(0.05)
        res, err = pk.write1ByteTxRx(ph, DXL_ID, ADDR_TORQUE_ENABLE, 0)
        print(f"torque off -> comm:{res} err:{err}")   # ambos deben ser 0
        time.sleep(0.1)
    finally:
        ph.closePort()
    print("\nApagado.")
    sys.exit(0)

signal.signal(signal.SIGINT,  apagar)
signal.signal(signal.SIGTERM, apagar)

set_corriente(0)   # sin empuje: lo mueves tú libremente
print("Mueve el codo a la HORIZONTAL y apunta el ángulo. Ctrl+C para salir.")
while True:
    print(f"θ = {math.degrees(leer_angulo()):7.1f}°    corriente medida = {leer_corriente():5d}")
    time.sleep(0.1)