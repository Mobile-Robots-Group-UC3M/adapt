import math
import time
import threading
import pybullet as p
import pybullet_data
from dynamixel_sdk import PortHandler, PacketHandler
import rospy
import os
import sys
import numpy as np
import roboticstoolbox as rtb
from roboticstoolbox import RevoluteDH
from sensor_msgs.msg import JointState

# Importamos ADAMSim
sys.path.append(os.path.join(os.path.dirname(__file__), "AdamSim"))
from scripts.adam import ADAM

# URDF robot path and create ADAM instance
base_path = os.path.dirname(__file__)
robot_urdf_path = "/home/alumnos/tfg-laura/AdamSim/models/robot/rb1_base_description/robots/robotDummy.urdf"
adam = ADAM(robot_urdf_path, useRealTimeSimulation=True, used_fixed_base=True, use_ros=False)

# ════════════════════════════════════════════════════════════════════════════
#  CONFIGURACION DE LOS DOS BRAZOS
# ════════════════════════════════════════════════════════════════════════════
PORT_2      = "/dev/ttyUSB1"
MOTOR_IDS_2 = [1, 2, 3, 4, 5, 6]
SIGNS_2     = [1, 1, -1, 1, 1, 1]
OFFSETS_2 = [-2.8769, -4.4879, 3.0840, 3.2282, -3.0217, 1.5567]

PORT_1      = "/dev/ttyUSB0"
MOTOR_IDS_1 = [8, 9, 10, 11, 12, 13]
SIGNS_1     = [1, 1, -1, 1, 1, 1]
OFFSETS_1 = [-6.2262, -3.3671, 3.1002, -1.6222, -3.2817, -4.6493]

BAUDRATE  = 57600
PROTOCOL  = 2.0

ADDR_PRESENT_POSITION = 132
TICKS_POR_VUELTA      = 4096
ADDR_OPERATING_MODE   = 11
ADDR_TORQUE_ENABLE    = 64
ADDR_GOAL_CURRENT     = 102
CURRENT_CONTROL_MODE  = 0

# ════════════════════════════════════════════════════════════════════════════
#  GRAVITY COMPENSATION & KINEMATICS
# ════════════════════════════════════════════════════════════════════════════
M     = [0.041, 0.063, 0.065, 0.034, 0.030, 0.074]
A     = [0.0,   -0.135, -0.105, 0.0,    0.0,    0.0]
D     = [0.01,   0.0,    0.0,    0.04,   0.03,   0.02]
ALPHA = [math.pi/2, 0.0, 0.0, math.pi/2, -math.pi/2, 0.0]
R = [
    [0.0,  -0.010, 0.0],
    [0.072, 0.0,   0.064],
    [0.025, 0.0,   0.012],
    [0.0,   0.0,   0.005],
    [0.0,   0.0,   0.005],
    [0.0,   0.0,  -0.010],
]

_links = [RevoluteDH(a=A[i], d=D[i], alpha=ALPHA[i], m=M[i], r=R[i],
                     I=[1e-5, 1e-5, 1e-5, 0, 0, 0]) for i in range(6)]
robot = rtb.DHRobot(_links, name="gello_leader")

def gravedad_desde_angulos(tilt_deg, azimut_deg, g=-9.81):
    """Calcula la gravedad usando matrices de rotacion formales Z * Y * g"""
    t = math.radians(tilt_deg)
    a = math.radians(azimut_deg)
    
    # Rotacion en Pitch (Tilt)
    Ry = np.array([[math.cos(t),  0, math.sin(t)],
                   [0,            1, 0          ],
                   [-math.sin(t), 0, math.cos(t)]])
    
    # Rotacion en Yaw (Azimut)
    Rz = np.array([[math.cos(a), -math.sin(a), 0],
                   [math.sin(a),  math.cos(a), 0],
                   [0,            0,           1]])
                   
    g_world = np.array([0.0, 0.0, g])
    g_base = Rz @ Ry @ g_world
    return g_base.tolist()

# ── Ajustes y Seguridad ───────────────────────────
GAIN        = 0.4
K_CURRENT   = 1500.0
MAX_CURRENT = 120 # Reducido ligeramente por seguridad
C_FRICCION  = [15, 15, 10, 5, 5, 5] # Corriente extra para vencer la friccion estatica
K_TANH      = 2.0 # Suavidad de la transicion de la friccion

ACTIVO_1 = [1, 1, 1, 1, 0, 0]
ACTIVO_2 = [1, 1, 1, 1, 0, 0]

CURRENT_SIGN_1 = [-1, 1, 1, 1, 1, 1]
CURRENT_SIGN_2 = [-1, 1, 1, 1, 1, 1]

TILT_DEG = 45
AZIMUT_1 = 90
AZIMUT_2 = -90
GRAVEDAD_1 = gravedad_desde_angulos(TILT_DEG, AZIMUT_1)
GRAVEDAD_2 = gravedad_desde_angulos(TILT_DEG, AZIMUT_2)

ESCALA_1 = [1.0, 1.0, 1.0, 1.0, 1.0, 1.0]
ESCALA_2 = [1.0, 1.0, 1.0, 0.4, 1.0, 1.0]

START_TIME = time.time()
SOFT_START_DURATION = 3.0 # Segundos que tarda en aplicar el 100% de la gravedad

def ticks_a_rad(ticks):
    ticks_norm = ticks % TICKS_POR_VUELTA
    return (ticks_norm / TICKS_POR_VUELTA) * 2 * math.pi

def normalizar_grados(deg):
    return ((deg + 180) % 360) - 180

def aplicar_transformacion(ticks_list, signs, offsets):
    return [signs[i] * ticks_a_rad(t) + offsets[i] for i, t in enumerate(ticks_list)]

def obtener_multiplicador_soft_start():
    elapsed = time.time() - START_TIME
    if elapsed >= SOFT_START_DURATION:
        return 1.0
    # Suavizado coseno (0 a 1) para evitar tirones
    return (1.0 - math.cos(math.pi * (elapsed / SOFT_START_DURATION))) / 2.0

def corriente_gravedad(q, signs, current_sign, activo, gravedad, escala):
    """Calcula par y compensa friccion no lineal."""
    tau = robot.gravload(q, gravity=gravedad)
    corrientes = []
    
    soft_start = obtener_multiplicador_soft_start()
    
    for i in range(6):
        if activo[i]:
            # Modelo: I = Ktau + Fricciontanh(k*tau)
            base_current = GAIN * K_CURRENT * tau[i]
            fric_current = C_FRICCION[i] * math.tanh(K_TANH * tau[i])
            c_total = current_sign[i] * signs[i] * escala[i] * (base_current ) * soft_start
        else:
            c_total = 0
            
        corrientes.append(int(np.clip(c_total, -MAX_CURRENT, MAX_CURRENT)))
    return corrientes


# ── Estado compartido y Filtro EMA ──────────────────────────────────────────
q_brazo1 = [0.0] * 6
q_brazo2 = [0.0] * 6
lock_q1  = threading.Lock()
lock_q2  = threading.Lock()
running  = True
EMA_ALPHA = 0.6 # Factor de suavizado (1.0 = sin filtro, valores mas bajos = mas suave pero con retraso)

# ── ROS ─────────────────────────────────────────────────────────────────────
rospy.init_node('gello_publisher', anonymous=True, disable_signals=True)

# ── Dynamixel: abrir puertos ────────────────────────────────────────────────
def init_puerto(port):
    ph = PortHandler(port)
    pk = PacketHandler(PROTOCOL)
    if not ph.openPort() or not ph.setBaudRate(BAUDRATE):
        raise IOError(f"No se pudo inicializar {port}")
    return ph, pk

port_handler_1, packet_handler_1 = init_puerto(PORT_1)
port_handler_2, packet_handler_2 = init_puerto(PORT_2)
lock_port1 = threading.Lock()
lock_port2 = threading.Lock()

def configurar_corriente(port, packet, motor_ids, etiqueta):
    for mid in motor_ids:
        packet.write1ByteTxRx(port, mid, ADDR_TORQUE_ENABLE, 0)
        time.sleep(0.01)
        packet.write1ByteTxRx(port, mid, ADDR_OPERATING_MODE, CURRENT_CONTROL_MODE)
        packet.write2ByteTxRx(port, mid, ADDR_GOAL_CURRENT, 0)
        packet.write1ByteTxRx(port, mid, ADDR_TORQUE_ENABLE, 1)

def escribir_corrientes(motor_ids, corrientes, port, packet, lock_port):
    with lock_port:
        for mid, c in zip(motor_ids, corrientes):
            packet.write2ByteTxRx(port, mid, ADDR_GOAL_CURRENT, int(c) & 0xFFFF)

def apagar(motor_ids, port, packet, lock_port):
    with lock_port:
        for mid in motor_ids:
            packet.write2ByteTxRx(port, mid, ADDR_GOAL_CURRENT, 0)
            packet.write1ByteTxRx(port, mid, ADDR_TORQUE_ENABLE, 0)

# ── Lectura de motores (hilos) ──────────────────────────────────────────────
def hilo_lectura(motor_ids, signs, offsets, port_handler, packet_handler, lock_port, lock_q, q_ref):
    # Inicializar el vector filtrado
    q_filtrado = None
    
    while running:
        try:
            ticks_list = []
            for mid in motor_ids:
                with lock_port:
                    pos, res, err = packet_handler.read4ByteTxRx(port_handler, mid, ADDR_PRESENT_POSITION)
                if res == 0 and err == 0:
                    ticks_list.append(pos)
                else:
                    break
            
            if len(ticks_list) == len(motor_ids):
                q_nuevo = aplicar_transformacion(ticks_list, signs, offsets)
                
                # Aplicar filtro paso bajo (EMA)
                if q_filtrado is None:
                    q_filtrado = list(q_nuevo)
                else:
                    q_filtrado = [(EMA_ALPHA * nuevo) + ((1 - EMA_ALPHA) * prev) 
                                  for nuevo, prev in zip(q_nuevo, q_filtrado)]
                
                with lock_q:
                    q_ref[:] = q_filtrado
        except Exception:
            pass
        time.sleep(0.005)

configurar_corriente(port_handler_1, packet_handler_1, MOTOR_IDS_1, "B1")
configurar_corriente(port_handler_2, packet_handler_2, MOTOR_IDS_2, "B2")

threading.Thread(target=hilo_lectura, args=(MOTOR_IDS_1, SIGNS_1, OFFSETS_1, port_handler_1, packet_handler_1, lock_port1, lock_q1, q_brazo1), daemon=True).start()
threading.Thread(target=hilo_lectura, args=(MOTOR_IDS_2, SIGNS_2, OFFSETS_2, port_handler_2, packet_handler_2, lock_port2, lock_q2, q_brazo2), daemon=True).start()

# ── Hilo de GRAVEDAD ────────────────────────────────────────────────────────
GRAV_PERIODO = 0.05 

def hilo_gravedad():
    while running:
        try:
            with lock_q1: q1 = list(q_brazo1)
            with lock_q2: q2 = list(q_brazo2)
            
            c1 = corriente_gravedad(q1, SIGNS_1, CURRENT_SIGN_1, ACTIVO_1, GRAVEDAD_1, ESCALA_1)
            c2 = corriente_gravedad(q2, SIGNS_2, CURRENT_SIGN_2, ACTIVO_2, GRAVEDAD_2, ESCALA_2)
            
            escribir_corrientes(MOTOR_IDS_1, c1, port_handler_1, packet_handler_1, lock_port1)
            escribir_corrientes(MOTOR_IDS_2, c2, port_handler_2, packet_handler_2, lock_port2)
        except Exception:
            pass
        time.sleep(GRAV_PERIODO)

threading.Thread(target=hilo_gravedad, daemon=True).start()

# ════════════════════════════════════════════════════════════════════════════
#  BUCLE PRINCIPAL
# ════════════════════════════════════════════════════════════════════════════
print("\nIniciando compensacion de gravedad (Soft-Start 3s)...")
try:
    while p.isConnected() and not rospy.is_shutdown():
        with lock_q1: q1 = list(q_brazo1)
        with lock_q2: q2 = list(q_brazo2)

        '''for i in range(6):
            q1[i]=q1[i]*-1
            q2[i]=q2[i]*-1'''
        
        adam.arm_kinematics.set_arm_pose('left',  'joint', q2)
        adam.arm_kinematics.set_arm_pose('right', 'joint', q1)

        b1 = " ".join(f"J{i+1}:{normalizar_grados(math.degrees(q1[i])):>5.1f}º" for i in range(6))
        b2 = " ".join(f"J{i+1}:{normalizar_grados(math.degrees(q2[i])):>5.1f}º" for i in range(6))
        print(f"\rB1 [{b1}] | B2 [{b2}]", end="")
        
        time.sleep(0.05)

except KeyboardInterrupt:
    print("\n\nApagado solicitado por teclado...")
except Exception as e:
    print(f"\nError: {e}")
finally:
    running = False
    time.sleep(0.2)
    apagar(MOTOR_IDS_1, port_handler_1, packet_handler_1, lock_port1)
    apagar(MOTOR_IDS_2, port_handler_2, packet_handler_2, lock_port2)
    port_handler_1.closePort()
    port_handler_2.closePort()
    print("Motores libres, puertos cerrados de forma segura.")