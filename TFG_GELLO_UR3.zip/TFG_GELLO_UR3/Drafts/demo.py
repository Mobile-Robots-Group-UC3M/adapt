import math
import numpy as np
import roboticstoolbox as rtb

robot = rtb.models.UR3()

print("Visualización de prueba con pyplot.")
print("Se abrirá una ventana con el robot moviéndose.")
print("Cierra la ventana para detener.\n")

n_frames = 100
trayectoria = []

for i in range(n_frames):
    t = i * 0.1
    q = [
        math.sin(t * 0.5) * 0.8,
        math.sin(t * 0.4) * 0.6 - 0.5,
        math.sin(t * 0.6) * 0.7,
        math.sin(t * 0.8) * 0.5,
        math.sin(t * 1.0) * 0.4,
        math.sin(t * 0.3) * 0.6,
    ]
    trayectoria.append(q)

trayectoria = np.array(trayectoria)  # conversión necesaria

robot.plot(trayectoria, backend='pyplot', block=True)