#!/usr/bin/env python3
# ============================================================================
#  gello_ADAM_collision_block.py   (v3 - colisiones con geometria REAL)
# ----------------------------------------------------------------------------
#  Teleoperacion GELLO -> ADAMSim con BLOQUEO DIRECCIONAL por colision.
#
#  CAMBIO IMPORTANTE respecto a versiones anteriores:
#   - NO se usa el Signed Distance Field. El SDF necesita la theta completa
#     (42 DOF de ADAM) y se desincronizaba con la pose mostrada -> bloqueos
#     aleatorios y penetraciones.
#   - Ahora la distancia se mide con la GEOMETRIA REAL de PyBullet
#     (p.getClosestPoints) sobre un robot "fantasma" invisible puesto en la
#     pose candidata. Es exacto, ligero y todo corre en UN solo hilo -> sin
#     temblor.
#
#  Logica:
#   - Brazo LIBRE: ADAM sigue el GELLO en vivo.
#   - Si la pose candidata deja un brazo a < D_BLOCK de la mesa/objetos:
#     ADAM se congela en la ultima pose segura y el GELLO se bloquea (modo 5).
#   - Desbloqueo DIRECCIONAL: solo se suelta si te alejas (la distancia mejora).
# ============================================================================

import math
import time
import threading
import os
import sys

import numpy as np
import pybullet as p
import pybullet_data
from dynamixel_sdk import PortHandler, PacketHandler, GroupSyncRead, GroupSyncWrite

ADAMSIM_DIR = "/home/alumnos/tfg-laura/AdamSim"
sys.path.append(ADAMSIM_DIR)
from scripts.adam import ADAM

ROBOT_URDF = "/home/alumnos/tfg-laura/AdamSim/models/robot/rb1_base_description/robots/robotDummy.urdf"

# ════════════════════════════════════════════════════════════════════════════
#  1. ARRANCAR ADAMSim
# ════════════════════════════════════════════════════════════════════════════
adam = ADAM(ROBOT_URDF, useRealTimeSimulation=True, used_fixed_base=True, use_ros=False)
ADAM_BODY_ID = adam.robot_id
base_pos, base_orn = p.getBasePositionAndOrientation(ADAM_BODY_ID)
print(f"ADAM_BODY_ID = {ADAM_BODY_ID}  base_pos = {base_pos}")

# ════════════════════════════════════════════════════════════════════════════
#  CONFIGURACION DE LOS DOS BRAZOS (GELLO)
# ════════════════════════════════════════════════════════════════════════════
PORT_2      = "/dev/ttyUSB1"
MOTOR_IDS_2 = [1, 2, 3, 4, 5, 6]
SIGNS_2     = [1, 1, -1, 1, 1, 1]
OFFSETS_2   = [-2.8769, -4.4879, 3.0840, 3.2282, -3.0217, 1.5567]

PORT_1      = "/dev/ttyUSB0"
MOTOR_IDS_1 = [8, 9, 10, 11, 12, 13]
SIGNS_1     = [1, 1, -1, 1, 1, 1]
OFFSETS_1   = [-6.2262, -3.3671, 3.1002, -1.6222, -3.2817, -4.6493]

BAUDRATE  = 57600
PROTOCOL  = 2.0

ADDR_OPERATING_MODE   = 11
ADDR_TORQUE_ENABLE    = 64
ADDR_GOAL_CURRENT     = 102
ADDR_GOAL_POSITION    = 116
ADDR_PRESENT_POSITION = 132

TICKS_POR_VUELTA            = 4096
MODE_CURRENT_BASED_POSITION = 5

# ── Parametros de colision / bloqueo ────────────────────────────────────────
D_BLOCK   = 0.01    # m  bloquea a 1 cm
D_RELEASE = 0.03    # m  libera al pasar de 3 cm (histeresis, evita parpadeo)
SEARCH    = 0.25    # m  radio de busqueda de getClosestPoints
#                  J1   J2   J3   J4   J5   J6
CURRENT_HOLD  = [350, 500, 350, 220, 160, 160]
ACTIVO_1 = [1, 1, 1, 1, 1, 1]
ACTIVO_2 = [1, 1, 1, 1, 1, 1]

GELLO_KEYWORDS = ["shoulder_pan", "shoulder_lift", "elbow", "wrist_1", "wrist_2", "wrist_3"]

# ════════════════════════════════════════════════════════════════════════════
#  2. INDICES DE JOINTS Y LINKS DE CADA BRAZO (de la geometria real de ADAM)
# ════════════════════════════════════════════════════════════════════════════
joint_name_to_idx = {}
link_idx_side = {}   # link_index -> 'left' / 'right' / None
for j in range(p.getNumJoints(ADAM_BODY_ID)):
    info  = p.getJointInfo(ADAM_BODY_ID, j)
    jname = info[1].decode()
    lname = info[12].decode()
    joint_name_to_idx[jname] = j
    if "left_arm" in lname or lname.startswith("L_"):
        link_idx_side[j] = "left"
    elif "right_arm" in lname or lname.startswith("R_"):
        link_idx_side[j] = "right"

def _arm_joints(side):
    js = []
    for kw in GELLO_KEYWORDS:
        idx = next((v for k, v in joint_name_to_idx.items()
                    if (side in k) and (kw in k)), None)
        js.append(idx)
    return js

LEFT_ARM_JOINTS  = _arm_joints("left_arm")
RIGHT_ARM_JOINTS = _arm_joints("right_arm")
LEFT_LINKS  = {k for k, v in link_idx_side.items() if v == "left"}
RIGHT_LINKS = {k for k, v in link_idx_side.items() if v == "right"}
print(f"LEFT_ARM_JOINTS  = {LEFT_ARM_JOINTS}")
print(f"RIGHT_ARM_JOINTS = {RIGHT_ARM_JOINTS}")
print(f"#links izq = {len(LEFT_LINKS)}, #links der = {len(RIGHT_LINKS)}")

# ════════════════════════════════════════════════════════════════════════════
#  3. MESA + OBJETOS
# ════════════════════════════════════════════════════════════════════════════
def add_box(center, half, color):
    col = p.createCollisionShape(p.GEOM_BOX, halfExtents=half)
    vis = p.createVisualShape(p.GEOM_BOX, halfExtents=half, rgbaColor=color)
    return p.createMultiBody(baseMass=0, baseCollisionShapeIndex=col,
                             baseVisualShapeIndex=vis, basePosition=center)

#TABLE_CENTER = [0.55, 0.0, 0.50]
#TABLE_HALF   = [0.30, 0.45, 0.02]
OBST_IDS = []
#OBST_IDS.append(add_box(TABLE_CENTER, TABLE_HALF, [0.55, 0.35, 0.18, 1.0]))
# patas (visual + colision, por si los brazos bajan)
'''for sx in (-1, 1):
    for sy in (-1, 1):
        lx = TABLE_CENTER[0] + sx * (TABLE_HALF[0] - 0.03)
        ly = TABLE_CENTER[1] + sy * (TABLE_HALF[1] - 0.03)
        add_box([lx, ly, TABLE_CENTER[2] / 2],
                [0.02, 0.02, TABLE_CENTER[2] / 2], [0.4, 0.25, 0.12, 1.0])  # patas: solo visual'''
# objetos encima
OBST_IDS.append(add_box([0.50, -0.15, 0.82], [0.04, 0.04, 0.05], [0.2, 0.5, 0.9, 1.0]))
OBST_IDS.append(add_box([0.58,  0.18, 0.85], [0.05, 0.05, 0.08], [0.9, 0.7, 0.1, 1.0]))

# ════════════════════════════════════════════════════════════════════════════
#  4. ROBOT FANTASMA (invisible) para medir la distancia de la pose candidata
# ════════════════════════════════════════════════════════════════════════════
ghost_id = p.loadURDF(ROBOT_URDF, basePosition=base_pos, baseOrientation=base_orn,
                      useFixedBase=True)
n_ghost = p.getNumJoints(ghost_id)
for li in range(-1, n_ghost):
    p.changeVisualShape(ghost_id, li, rgbaColor=[0, 0, 0, 0])   # invisible (sube alpha para verlo)
    p.setCollisionFilterGroupMask(ghost_id, li, 0, 0)           # no interactua fisicamente

def set_ghost(q_left, q_right):
    for i, idx in enumerate(LEFT_ARM_JOINTS):
        if idx is not None: p.resetJointState(ghost_id, idx, q_left[i])
    for i, idx in enumerate(RIGHT_ARM_JOINTS):
        if idx is not None: p.resetJointState(ghost_id, idx, q_right[i])

def clearance_both():
    """Distancia minima (m) de cada brazo del fantasma a la mesa/objetos.
    Negativa si hay penetracion. Devuelve (d_left, d_right)."""
    dL = dR = 9.9
    for oid in OBST_IDS:
        for cp in p.getClosestPoints(ghost_id, oid, distance=SEARCH):
            li, d = cp[3], cp[8]
            if li in LEFT_LINKS:
                if d < dL: dL = d
            elif li in RIGHT_LINKS:
                if d < dR: dR = d
    return dL, dR

# ════════════════════════════════════════════════════════════════════════════
#  5. LECTURA DE LOS GELLO (hilos de serie, NO tocan PyBullet)
# ════════════════════════════════════════════════════════════════════════════
def ticks_a_rad(ticks):
    return ((ticks % TICKS_POR_VUELTA) / TICKS_POR_VUELTA) * 2 * math.pi

def normalizar_grados(deg):
    return ((deg + 180) % 360) - 180

def aplicar_transformacion(ticks_list, signs, offsets):
    return [signs[i] * ticks_a_rad(t) + offsets[i] for i, t in enumerate(ticks_list)]

q_brazo1 = [0.0] * 6; q_brazo2 = [0.0] * 6
ticks_actuales_1 = [0] * 6; ticks_actuales_2 = [0] * 6
lock_q1 = threading.Lock(); lock_q2 = threading.Lock()
running = True

def init_puerto(port):
    ph = PortHandler(port); pk = PacketHandler(PROTOCOL)
    if not ph.openPort():            raise IOError(f"No se pudo abrir {port}")
    if not ph.setBaudRate(BAUDRATE): raise IOError(f"Baudrate fallo en {port}")
    print(f"OK conectado a {port}")
    return ph, pk

ph1, pk1 = init_puerto(PORT_1)
ph2, pk2 = init_puerto(PORT_2)

sync_read_1 = GroupSyncRead(ph1, pk1, ADDR_PRESENT_POSITION, 4)
sync_read_2 = GroupSyncRead(ph2, pk2, ADDR_PRESENT_POSITION, 4)
for mid in MOTOR_IDS_1: sync_read_1.addParam(mid)
for mid in MOTOR_IDS_2: sync_read_2.addParam(mid)

lock_port1 = threading.Lock(); lock_port2 = threading.Lock()
_PORT_LOCKS = {ph1: lock_port1, ph2: lock_port2}
def _port_lock(port): return _PORT_LOCKS[port]

def hilo_lectura(motor_ids, signs, offsets, sync_read, lock_port, lock_q, q_ref, ticks_ref):
    while running:
        try:
            with lock_port:
                res = sync_read.txRxPacket()
            if res == 0:
                t_list = []
                for mid in motor_ids:
                    if sync_read.isAvailable(mid, ADDR_PRESENT_POSITION, 4):
                        pos = sync_read.getData(mid, ADDR_PRESENT_POSITION, 4)
                        if pos > 0x7FFFFFFF: pos -= 0x100000000
                        t_list.append(pos)
                if len(t_list) == 6:
                    q_nuevo = aplicar_transformacion(t_list, signs, offsets)
                    with lock_q:
                        q_ref[:] = q_nuevo; ticks_ref[:] = t_list
        except Exception:
            pass
        time.sleep(0.005)

# ════════════════════════════════════════════════════════════════════════════
#  6. EMBRAGUE DE BLOQUEO (modo 5). Libre = torque OFF (pasivo).
# ════════════════════════════════════════════════════════════════════════════
def set_modo5(port, pk, motor_ids):
    for mid in motor_ids:
        pk.write1ByteTxRx(port, mid, ADDR_TORQUE_ENABLE, 0); time.sleep(0.02)
        pk.write1ByteTxRx(port, mid, ADDR_OPERATING_MODE, MODE_CURRENT_BASED_POSITION); time.sleep(0.03)
        pk.write2ByteTxRx(port, mid, ADDR_GOAL_CURRENT, 0)

def engage_hold(port, pk, motor_ids, activo, locked_ticks):
    for i, mid in enumerate(motor_ids):
        if not activo[i]: continue
        pos_int = int(locked_ticks[i]) & 0xFFFFFFFF
        with _port_lock(port):
            pk.write4ByteTxRx(port, mid, ADDR_GOAL_POSITION, pos_int)
            pk.write2ByteTxRx(port, mid, ADDR_GOAL_CURRENT, CURRENT_HOLD[i])
            pk.write1ByteTxRx(port, mid, ADDR_TORQUE_ENABLE, 1)

def update_lock(port, pk, motor_ids, activo, goal_ticks):
    sync = GroupSyncWrite(port, pk, ADDR_GOAL_POSITION, 4)
    for i, mid in enumerate(motor_ids):
        if not activo[i]: continue
        v = int(goal_ticks[i]) & 0xFFFFFFFF
        sync.addParam(mid, [v & 0xFF, (v >> 8) & 0xFF, (v >> 16) & 0xFF, (v >> 24) & 0xFF])
    with _port_lock(port):
        sync.txPacket()
    sync.clearParam()

def release_hold(port, pk, motor_ids):
    with _port_lock(port):
        for mid in motor_ids:
            pk.write1ByteTxRx(port, mid, ADDR_TORQUE_ENABLE, 0)

set_modo5(ph1, pk1, MOTOR_IDS_1)
set_modo5(ph2, pk2, MOTOR_IDS_2)

threading.Thread(target=hilo_lectura,
                 args=(MOTOR_IDS_1, SIGNS_1, OFFSETS_1, sync_read_1, lock_port1, lock_q1, q_brazo1, ticks_actuales_1),
                 daemon=True).start()
threading.Thread(target=hilo_lectura,
                 args=(MOTOR_IDS_2, SIGNS_2, OFFSETS_2, sync_read_2, lock_port2, lock_q2, q_brazo2, ticks_actuales_2),
                 daemon=True).start()

# ════════════════════════════════════════════════════════════════════════════
#  7. BUCLE PRINCIPAL (un solo hilo: lee, comprueba colision, mueve ADAM)
# ════════════════════════════════════════════════════════════════════════════
time.sleep(0.6)
with lock_q2: q_safe2 = list(q_brazo2); safe_ticks2 = list(ticks_actuales_2)
with lock_q1: q_safe1 = list(q_brazo1); safe_ticks1 = list(ticks_actuales_1)
state2 = 0; state1 = 0   # 0 = libre, 1 = bloqueado

COLLISION_PERIOD = 0.05   # s  -> comprobar colision ~20 Hz (no frena la teleop)
last_col = 0.0
lbl1 = lbl2 = "LIBRE"
dL_cand = dR_cand = 9.9

# ── Cartel de estado en la ventana de simulacion ────────────────────────────
banner_id = None
BANNER_POS = [0.5, 0.0, 1.5]   # posicion en el mundo (sube/baja Z si no se ve bien)
def update_banner(dmin):
    global banner_id
    if dmin < 0.02:
        txt, col = "COLLISION DETECTED", [1.0, 0.0, 0.0]
    elif dmin < 0.05:
        txt, col = "APPROACHING OBJECT", [1.0, 0.85, 0.0]
    else:
        txt, col = "FREE TO MOVE", [0.0, 0.8, 0.0]
    if banner_id is None:
        banner_id = p.addUserDebugText(txt, BANNER_POS, textColorRGB=col, textSize=2.2)
    else:
        banner_id = p.addUserDebugText(txt, BANNER_POS, textColorRGB=col, textSize=2.2,
                                       replaceItemUniqueId=banner_id)

print("\n[+] Teleop + bloqueo por colision (geometria real). Ctrl+C para salir.\n")
try:
    while p.isConnected():
        with lock_q2: q2 = list(q_brazo2); t2 = list(ticks_actuales_2)
        with lock_q1: q1 = list(q_brazo1); t1 = list(ticks_actuales_1)

        # ── Comprobacion de colision a baja frecuencia ──────────────────────
        if time.time() - last_col >= COLLISION_PERIOD:
            last_col = time.time()
            set_ghost(q2, q1)                 # ambos en vivo -> candidata de los dos brazos
            dL_cand, dR_cand = clearance_both()

            # IZQUIERDA (ADAM left = GELLO brazo 2)
            if state2 == 0:
                if dL_cand < D_BLOCK:
                    state2 = 1; engage_hold(ph2, pk2, MOTOR_IDS_2, ACTIVO_2, safe_ticks2); lbl2 = "BLOQUEA"
                else:
                    q_safe2 = q2; safe_ticks2 = t2; lbl2 = "LIBRE"
            else:
                set_ghost(q_safe2, q1); dL_frozen, _ = clearance_both()
                if dL_cand > D_RELEASE:
                    state2 = 0; release_hold(ph2, pk2, MOTOR_IDS_2); q_safe2 = q2; safe_ticks2 = t2; lbl2 = "LIBRE"
                elif dL_cand > dL_frozen + 1e-4:
                    q_safe2 = q2; safe_ticks2 = t2; update_lock(ph2, pk2, MOTOR_IDS_2, ACTIVO_2, t2); lbl2 = "RETIRA"
                else:
                    update_lock(ph2, pk2, MOTOR_IDS_2, ACTIVO_2, safe_ticks2); lbl2 = "MURO"

            # DERECHA (ADAM right = GELLO brazo 1)
            if state1 == 0:
                if dR_cand < D_BLOCK:
                    state1 = 1; engage_hold(ph1, pk1, MOTOR_IDS_1, ACTIVO_1, safe_ticks1); lbl1 = "BLOQUEA"
                else:
                    q_safe1 = q1; safe_ticks1 = t1; lbl1 = "LIBRE"
            else:
                set_ghost(q2, q_safe1); _, dR_frozen = clearance_both()
                if dR_cand > D_RELEASE:
                    state1 = 0; release_hold(ph1, pk1, MOTOR_IDS_1); q_safe1 = q1; safe_ticks1 = t1; lbl1 = "LIBRE"
                elif dR_cand > dR_frozen + 1e-4:
                    q_safe1 = q1; safe_ticks1 = t1; update_lock(ph1, pk1, MOTOR_IDS_1, ACTIVO_1, t1); lbl1 = "RETIRA"
                else:
                    update_lock(ph1, pk1, MOTOR_IDS_1, ACTIVO_1, safe_ticks1); lbl1 = "MURO"

            print(f"izq {dL_cand*100:5.1f}cm [{lbl2:7s}]  der {dR_cand*100:5.1f}cm [{lbl1:7s}]")
            update_banner(min(dL_cand, dR_cand))

        # ── Mover ADAM CADA iteracion (fluido): libre=en vivo, bloqueado=congelado ──
        adam.arm_kinematics.set_arm_pose('left',  'joint', q_safe2 if state2 else q2)
        adam.arm_kinematics.set_arm_pose('right', 'joint', q_safe1 if state1 else q1)
        time.sleep(0.01)

except KeyboardInterrupt:
    print("\nDeteniendo...")
except Exception as e:
    print(f"\nError: {e}")
finally:
    running = False
    time.sleep(0.2)
    release_hold(ph1, pk1, MOTOR_IDS_1)
    release_hold(ph2, pk2, MOTOR_IDS_2)
    ph1.closePort(); ph2.closePort()
    print("Motores liberados, puertos cerrados.")