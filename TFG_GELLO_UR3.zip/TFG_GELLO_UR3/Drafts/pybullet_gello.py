import math
import time
import threading
import pybullet as p
import pybullet_data
from dynamixel_sdk import PortHandler, PacketHandler

# ── Configuración ─────────────────────────────────────────────────────────────
PORT = "/dev/serial/by-id/usb-FTDI_USB__-__Serial_Converter_FTB8HQBA-if00-port0" #! Si no se conecat hay que hacer el 'sudo chmod 666 /dev/serial/by-id/usb-FTDI_USB__-__Serial_Converter_FTB8HQBA-if00-port0'
#PORT = "/dev/ttyUSB0" #! Si no se conecat hay que hacer el 'sudo chmod 666 /dev/ttyUSB0'
#PORT = "usb-FTDI_USB__-__Serial_Converter_FTB8HQS0-if00-port0"
BAUDRATE  = 57600
PROTOCOL  = 2.0
#MOTOR_IDS = [1, 2, 3, 4, 5, 6]
MOTOR_IDS = [8, 9, 10, 11, 12, 13]

URDF_PATH = "/home/alumnos/tfg-laura/robotics-toolbox/xacro_generated/ur_description/urdf/ur3.urdf"

ADDR_PRESENT_POSITION = 132
TICKS_POR_VUELTA      = 4096

JOINT_SIGNS   = [1, 1, -1, 1, 1, 1]
#JOINT_OFFSETS = [-3.212, -4.746, 3.173, -3.158, -3.177, -1.466]
JOINT_OFFSETS = [-3.212, -9.459, 3.173, -1.587, -3.177, 1.466]

# ── Conversión ────────────────────────────────────────────────────────────────
def ticks_a_rad(ticks):
    return (ticks / TICKS_POR_VUELTA) * 2 * math.pi

def aplicar_transformacion(ticks_list):
    return [JOINT_SIGNS[i] * ticks_a_rad(t) + JOINT_OFFSETS[i]
            for i, t in enumerate(ticks_list)]

# ── Estado compartido ─────────────────────────────────────────────────────────
q_actual  = [0.0] * 6
lock_q    = threading.Lock()
lock_port = threading.Lock()
running   = True

# ── Inicializar comunicación Dynamixel ────────────────────────────────────────
port_handler   = PortHandler(PORT)
packet_handler = PacketHandler(PROTOCOL)

if not port_handler.openPort():
    raise IOError(f"No se pudo abrir {PORT}. ¿Está el U2D2 conectado?")
if not port_handler.setBaudRate(BAUDRATE):
    raise IOError(f"No se pudo configurar el baudrate {BAUDRATE}.")

print(f"✓ Conectado a {PORT}")

def leer_posicion(motor_id):
    try:
        with lock_port:
            pos, result, error = packet_handler.read4ByteTxRx(
                port_handler, motor_id, ADDR_PRESENT_POSITION)
        if result != 0 or error != 0:
            return None
        return pos
    except Exception:
        return None

# ── Hilo de lectura ───────────────────────────────────────────────────────────
def hilo_lectura():
    global q_actual
    while running:
        try:
            ticks_list = []
            hay_error  = False
            for motor_id in MOTOR_IDS:
                pos = leer_posicion(motor_id)
                if pos is None:
                    hay_error = True
                    break
                ticks_list.append(pos)

            if not hay_error:
                q_nuevo = aplicar_transformacion(ticks_list)
                with lock_q:
                    q_actual = q_nuevo
                print("  ".join(
                    f"J{i+1}:{math.degrees(q_actual[i]):>7.1f}°"
                    for i in range(6)
                ), end="\r")
        except Exception:
            pass

threading.Thread(target=hilo_lectura, daemon=True).start()

# ── Inicializar PyBullet ──────────────────────────────────────────────────────
p.connect(p.GUI)
p.setAdditionalSearchPath(pybullet_data.getDataPath())
p.setGravity(0, 0, 0)          # sin gravedad — solo visualización cinemática
p.resetDebugVisualizerCamera(
    cameraDistance=1.2,
    cameraYaw=45,
    cameraPitch=-30,
    cameraTargetPosition=[0, 0, 0.3]
)

# Cargar suelo y robot
p.loadURDF("plane.urdf")
robot_id = p.loadURDF(URDF_PATH, basePosition=[0, 0, 0], useFixedBase=True)

# Identificar las articulaciones móviles (tipo REVOLUTE) del URDF
joints_moviles = []
for i in range(p.getNumJoints(robot_id)):
    info = p.getJointInfo(robot_id, i)
    if info[2] == p.JOINT_REVOLUTE:
        joints_moviles.append(i)

print(f"✓ Robot cargado. Articulaciones encontradas: {joints_moviles}")
print("  Mueve el GELLO para ver el robot moverse.")
print("  Cierra la ventana de PyBullet para detener.\n")

# Leer posición inicial y aplicarla
time.sleep(0.5)
with lock_q:
    q_inicio = list(q_actual)
for i, joint_idx in enumerate(joints_moviles[:6]):
    p.resetJointState(robot_id, joint_idx, q_inicio[i])

# ── Bucle principal ───────────────────────────────────────────────────────────
try:
    while p.isConnected():
        with lock_q:
            q = list(q_actual)

        # Mover cada articulación del modelo a la posición leída
        for i, joint_idx in enumerate(joints_moviles[:6]):
            p.setJointMotorControl2(
                bodyUniqueId=robot_id,
                jointIndex=joint_idx,
                controlMode=p.POSITION_CONTROL,
                targetPosition=q[i],
                force=500
            )

        p.stepSimulation()
        time.sleep(0.05)  # ~20 Hz

except Exception as e:
    print(f"\nError: {e}")

finally:
    running = False
    time.sleep(0.2)
    port_handler.closePort()
    print("Puerto cerrado.")