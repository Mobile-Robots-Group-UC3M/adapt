#!/usr/bin/env python3
# ============================================================================
#  Gravity compensation para los brazos GELLO  (inspirado en FACTR_Teleop)
#
#  En cada vuelta: leemos la posicion de los motores -> calculamos con un
#  modelo fisico (roboticstoolbox) cuanta fuerza hace falta para sostener el
#  brazo contra la gravedad -> la mandamos a los motores como corriente.
#  Resultado: el brazo "flota" y se mueve suave con un dedo.
#
#  Usa roboticstoolbox (la que ya tienes). NO necesita Pinocchio ni el URDF.
#  SOLO gravity comp (sin ADAMSim): es para ajustar la flotacion primero.
# ============================================================================

import time
import math
import numpy as np
import roboticstoolbox as rtb
from roboticstoolbox import RevoluteDH
from dynamixel_sdk import PortHandler, PacketHandler

# ── MODELO FISICO DEL BRAZO (UR3 escalado a tus medidas + tus pesos) ────────
#  M  = masa por link (kg): parte impresa + su motor
#  A  = largo de cada link (m): A[1]=L2 (motor2->3), A[2]=L3 (motor3->4)
#  D  = offsets a lo largo del eje (m): D[3..5] = muñeca; D[0]=altura base
#  R  = centro de masa de cada link (m), en el sistema del link
M     = [0.041, 0.063, 0.065, 0.034, 0.030, 0.074]
A     = [0.0,   -0.135, -0.105, 0.0,    0.0,    0.0]
D     = [0.44,   0.0,    0.0,    0.04,   0.03,   0.02]
ALPHA = [math.pi/2, 0.0, 0.0, math.pi/2, -math.pi/2, 0.0]
R = [
    [0.0,  -0.010, 0.0],
    [0.072, 0.0,   0.064],
    [0.025, 0.0,   0.012],
    [0.0,   0.0,   0.005],
    [0.0,   0.0,   0.005],
    [0.0,   0.0,  -0.010],
]
_links = [RevoluteDH(a=A[i], d=D[i], alpha=ALPHA[i], m=M[i], r=R[i],
                     I=[1e-5, 1e-5, 1e-5, 0, 0, 0]) for i in range(6)]
robot = rtb.DHRobot(_links, name="gello_leader")

# ── AJUSTES PRINCIPALES (esto es lo que vas a tocar) ────────────────────────
GAIN = 0.4          # 0.0 = sin ayuda (brazo suelto) ; 1.0 = compensa el 100%.
                    # EMPIEZA EN 0.0 para sentir el brazo flojo. Luego 0.3, 0.5...
K_CURRENT = 1500.0  # par->corriente (unidades de corriente por N*m). CALIBRAR luego.
MAX_CURRENT = 150   # tope de corriente por motor (seguridad).

# ACTIVO: que juntas reciben compensacion (1) y cuales se quedan flojas (0).
# Sirve para probar UNA junta cada vez. Orden: [J1,J2,J3,J4,J5,J6].
# Las importantes son J2 y J3 (hombro y codo); el resto casi no pesa.
ACTIVO_1 = [0, 0, 0, 0, 0, 0]   # brazo 1 (motores 8-13)
ACTIVO_2 = [1, 1, 1, 0, 0, 0]   # brazo 2 (motores 1-6)

# SIGNO de la corriente por junta y POR BRAZO (los brazos son espejo).
# Si una junta PELEA (se va al tope, se siente mas pesada), cambia su 1 por -1.
CURRENT_SIGN_1 = [1, 1, 1, 1, 1, 1]   # brazo 1
CURRENT_SIGN_2 = [-1, 1, 1, 1, 1, 1]   # brazo 2

# DIRECCION DE LA GRAVEDAD para cada brazo [x, y, z], en m/s^2.
#  - Si el GELLO estuviera sobre una mesa: [0, 0, -9.81] (recta hacia abajo).
#  - Tu torso esta inclinado 45 grados y los dos brazos son espejo, asi que
#    la gravedad va inclinada hacia lados opuestos. Valores de partida (45 grados):
GRAVEDAD_1 = [0.0, 6.94, 6.94]   # brazo 1 (motores 8-13)
GRAVEDAD_2 = [0.0, -6.94, 6.94]   # brazo 2 (motores 1-6)

# ESCALA de ayuda por junta (1 = normal, 0.5 = la mitad, 0 = nada).
# Sirve para suavizar una junta que se pasa de fuerza (p.ej. J1).
ESCALA_1 = [1.0, 1.0, 1.0, 1.0, 1.0, 1.0]   # brazo 1
ESCALA_2 = [1.0, 1.0, 1.0, 1.0, 1.0, 1.0]   # brazo 2

# ── Configuracion de los dos brazos (igual que en gello_v2_ADAM.py) ─────────
PORT_2      = "/dev/ttyUSB0"
MOTOR_IDS_2 = [1, 2, 3, 4, 5, 6]
SIGNS_2     = [1, 1, -1, 1, 1, 1]
OFFSETS_2   = [-4.6222, -4.4879, 3.0840, 3.2282, -3.0217, 1.5567]

PORT_1      = "/dev/ttyUSB1"
MOTOR_IDS_1 = [8, 9, 10, 11, 12, 13]
SIGNS_1     = [1, 1, -1, 1, 1, 1]
OFFSETS_1   = [-3.0846, -3.3671, 3.1002, -1.6222, -3.2817, -4.6493]

BAUDRATE = 57600
PROTOCOL = 2.0
TICKS_POR_VUELTA = 4096

ADDR_OPERATING_MODE   = 11
ADDR_TORQUE_ENABLE    = 64
ADDR_GOAL_CURRENT     = 102
ADDR_PRESENT_POSITION = 132
CURRENT_CONTROL_MODE  = 0


def ticks_a_rad(ticks):
    return (ticks / TICKS_POR_VUELTA) * 2 * math.pi

def leer_q(motor_ids, signs, offsets, port, packet):
    """Lee los 6 motores de un brazo y devuelve q (rad) o None si falla."""
    q = []
    for i, mid in enumerate(motor_ids):
        pos, res, err = packet.read4ByteTxRx(port, mid, ADDR_PRESENT_POSITION)
        if res != 0 or err != 0:
            return None
        q.append(signs[i] * ticks_a_rad(pos) + offsets[i])
    return np.array(q)

def corriente_gravedad(q, signs, current_sign, activo, gravedad, escala):
    """De la posicion q saca el par de gravedad y lo pasa a corriente por motor."""
    tau = robot.gravload(q, gravity=gravedad)     # N*m en cada junta
    corrientes = []
    for i in range(6):
        c = activo[i] * escala[i] * current_sign[i] * signs[i] * GAIN * K_CURRENT * tau[i]
        c = int(np.clip(c, -MAX_CURRENT, MAX_CURRENT))
        corrientes.append(c)
    return corrientes, tau

def _escribir_byte_seguro(packet, port, mid, addr, val, intentos=5):
    """Escribe un byte reintentando si hay error de comunicacion."""
    for _ in range(intentos):
        res, err = packet.write1ByteTxRx(port, mid, addr, val)
        if res == 0 and err == 0:
            return True
        time.sleep(0.01)
    return False

def init_puerto(port_name, motor_ids):
    port = PortHandler(port_name)
    packet = PacketHandler(PROTOCOL)
    if not port.openPort():
        raise IOError(f"No se pudo abrir {port_name}")
    if not port.setBaudRate(BAUDRATE):
        raise IOError(f"No se pudo poner baudrate en {port_name}")
    print(f"\nConfigurando {port_name}:")
    for mid in motor_ids:
        # 1) apagar torque (obligatorio para cambiar el modo)
        _escribir_byte_seguro(packet, port, mid, ADDR_TORQUE_ENABLE, 0)
        time.sleep(0.02)
        # 2) poner modo corriente, reintentando hasta que se confirme
        modo_ok = False
        for intento in range(5):
            _escribir_byte_seguro(packet, port, mid, ADDR_OPERATING_MODE,
                                  CURRENT_CONTROL_MODE)
            time.sleep(0.03)
            modo, res, err = packet.read1ByteTxRx(port, mid, ADDR_OPERATING_MODE)
            if res == 0 and err == 0 and modo == CURRENT_CONTROL_MODE:
                modo_ok = True
                break
        # 3) corriente 0 y encender torque -> motor flojo (listo)
        packet.write2ByteTxRx(port, mid, ADDR_GOAL_CURRENT, 0)
        _escribir_byte_seguro(packet, port, mid, ADDR_TORQUE_ENABLE, 1)
        if modo_ok:
            print(f"  ID {mid:2d}: OK (modo corriente, debe quedar FLOJO)")
        else:
            print(f"  ID {mid:2d}: !! NO cambio a modo corriente -> quedara RIGIDO")
    print(f"✓ {port_name} configurado")
    return port, packet

def escribir_corrientes(motor_ids, corrientes, port, packet):
    for mid, c in zip(motor_ids, corrientes):
        packet.write2ByteTxRx(port, mid, ADDR_GOAL_CURRENT, int(c) & 0xFFFF)

def apagar(motor_ids, port, packet):
    for mid in motor_ids:
        packet.write2ByteTxRx(port, mid, ADDR_GOAL_CURRENT, 0)
        packet.write1ByteTxRx(port, mid, ADDR_TORQUE_ENABLE, 0)


def main():
    port1, packet1 = init_puerto(PORT_1, MOTOR_IDS_1)
    port2, packet2 = init_puerto(PORT_2, MOTOR_IDS_2)
    print(f"\nGAIN={GAIN}  K_CURRENT={K_CURRENT}  MAX_CURRENT={MAX_CURRENT}")
    print("Mueve los brazos con la mano. Ctrl+C para parar.\n")
    try:
        while True:
            for (ids, signs, offs, csign, activo, grav, esc, port, packet, lbl) in [
                (MOTOR_IDS_1, SIGNS_1, OFFSETS_1, CURRENT_SIGN_1, ACTIVO_1, GRAVEDAD_1, ESCALA_1, port1, packet1, "B1"),
                (MOTOR_IDS_2, SIGNS_2, OFFSETS_2, CURRENT_SIGN_2, ACTIVO_2, GRAVEDAD_2, ESCALA_2, port2, packet2, "B2"),
            ]:
                q = leer_q(ids, signs, offs, port, packet)
                if q is None:
                    continue
                corrientes, tau = corriente_gravedad(q, signs, csign, activo, grav, esc)
                escribir_corrientes(ids, corrientes, port, packet)
                txt = "  ".join(f"J{i+1}:{tau[i]:+.3f}Nm/{corrientes[i]:+4d}"
                                for i in range(6))
                print(f"{lbl} {txt}")
            print("")
            time.sleep(0.02)
    except KeyboardInterrupt:
        print("\nParando, soltando motores...")
    finally:
        apagar(MOTOR_IDS_1, port1, packet1)
        apagar(MOTOR_IDS_2, port2, packet2)
        port1.closePort()
        port2.closePort()
        print("Motores libres, puertos cerrados.")


if __name__ == "__main__":
    main()