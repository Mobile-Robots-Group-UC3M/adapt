import math
import numpy as np
import roboticstoolbox as rtb
from roboticstoolbox import RevoluteDH
from spatialmath import SE3

# =====================================================================
# 1. DEFINICIÓN DE TU MODELO GELLO (El Maestro)
# =====================================================================
M     = [0.041, 0.063, 0.065, 0.034, 0.030, 0.074]
A     = [0.0,   -0.135, -0.105, 0.0,    0.0,    0.0]
D     = [0.01,   0.0,    0.0,    0.04,   0.03,   0.02]
ALPHA = [math.pi/2, 0.0, 0.0, math.pi/2, -math.pi/2, 0.0]

links_gello = [RevoluteDH(a=A[i], d=D[i], alpha=ALPHA[i], m=M[i]) for i in range(6)]
gello_robot = rtb.DHRobot(links_gello, name="GELLO_Custom")

# Desplazamos la base del GELLO 0.4 metros en Y para que no se superpongan visualmente
gello_robot.base = SE3(0.0, 0.4, 0.0) 

# =====================================================================
# 2. CARGAR EL MODELO UR3 OFICIAL (El Esclavo / Simulador)
# =====================================================================
# roboticstoolbox incluye el UR3 estándar modelado con DH
ur3_robot = rtb.models.DH.UR3()
ur3_robot.name = "UR3_Oficial"

# =====================================================================
# 3. COMPARAR TABLAS DH POR CONSOLA
# =====================================================================
print("\n" + "="*50)
print(" TABLA DH: UR3 OFICIAL")
print("="*50)
print(ur3_robot)

print("\n" + "="*50)
print(" TABLA DH: TU GELLO CUSTOM")
print("="*50)
print(gello_robot)
print("\nFíjate especialmente en los signos de 'a' y 'alpha'. Si están invertidos,")
print("los ejes de rotación de tu modelo apuntan al lado contrario que los del UR3.\n")

# =====================================================================
# 4. VISUALIZACIÓN 3D
# =====================================================================
# Ponemos ambos robots en su posición "Cero" (q = 0 para todos los motores)
q_zero = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0]

print("Abriendo visualizador 3D... (Cierra la ventana para terminar el programa)")

# Usamos el backend de PyPlot para dibujar ambos en la misma figura
env = rtb.backends.PyPlot()
env.launch()
env.add(ur3_robot)
env.add(gello_robot)

# Aplicamos la posición cero
ur3_robot.q = q_zero
gello_robot.q = q_zero

# Renderizamos y mantenemos la ventana abierta
env.step()
env.hold()