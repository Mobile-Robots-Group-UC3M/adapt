import math
import time
import threading
import pybullet as p
import pybullet_data
from dynamixel_sdk import PortHandler, PacketHandler
import rospy
from sensor_msgs.msg import JointState

# ── Configuración brazo 1 (IZQUIERDA) ─────────────────────────────────────────
PORT_2      = "/dev/ttyUSB1"
MOTOR_IDS_2 = [1, 2, 3, 4, 5, 6]
SIGNS_2     = [1, 1, -1, 1, 1, 1]
#OFFSETS_1   = [-3.212, -5.5314, 2.65, -3.158, -3.177, -1.466]

#OFFSETS_1  = [-3.1230, -3.0585, 3.1084, 1.6347, -3.1578, 3.1921]



# ── Configuración brazo 2 (DERECHA) ───────────────────────────────────────────
PORT_1      = "/dev/ttyUSB0"
MOTOR_IDS_1 = [8, 9, 10, 11, 12, 13]
SIGNS_1     = [1, 1, -1, 1, 1, 1]
#OFFSETS_2   = [-3.212, -2.390, 3.173, -0.889, -3.177, 1.466]


#OFFSETS_2   = [-3.1928, -4.7285, 3.1369, -3.1563, -4.8665, -3.1169]

OFFSETS_1 = [-3.0846, -3.3671, 3.1002, -0.0514, -4.8525, -4.6493]
OFFSETS_2 = [-4.6222, -4.4879, 3.0840, 1.6574, -1.4509, 1.5567]

# ── Configuración común ───────────────────────────────────────────────────────
BAUDRATE  = 57600
PROTOCOL  = 2.0
URDF_PATH = "/home/alumnos/tfg-laura/robotics-toolbox/xacro_generated/ur_description/urdf/ur3.urdf"

ADDR_PRESENT_POSITION = 132
TICKS_POR_VUELTA      = 4096

# ── Orden de joints que espera ADAMSim (orden robot real UR3) ─────────────────
# ADAMSim hace swap [0]↔[2] al recibir, así que publicamos:
# [elbow, shoulder_lift, shoulder_pan, wrist_1, wrist_2, wrist_3]
# Tu q_brazo viene en orden GELLO: [pan, lift, elbow, w1, w2, w3]
# → hay que reordenar: [2, 1, 0, 3, 4, 5]

JOINT_NAMES_LEFT = [
    'robot_left_arm_elbow_joint',
    'robot_left_arm_shoulder_lift_joint',
    'robot_left_arm_shoulder_pan_joint',
    'robot_left_arm_wrist_1_joint',
    'robot_left_arm_wrist_2_joint',
    'robot_left_arm_wrist_3_joint',
]
JOINT_NAMES_RIGHT = [
    'robot_right_arm_elbow_joint',
    'robot_right_arm_shoulder_lift_joint',
    'robot_right_arm_shoulder_pan_joint',
    'robot_right_arm_wrist_1_joint',
    'robot_right_arm_wrist_2_joint',
    'robot_right_arm_wrist_3_joint',
]

def reorder_para_adamsim(q):
    """
    Tu q viene en orden GELLO [pan, lift, elbow, w1, w2, w3].
    ADAMSim espera [elbow, lift, pan, w1, w2, w3] y luego hace swap internamente.
    """
    return [q[2], q[1], q[0], q[3], q[4], q[5]]

# ── Conversión ────────────────────────────────────────────────────────────────
def ticks_a_rad(ticks):
    ticks_norm = ticks % TICKS_POR_VUELTA
    return (ticks_norm / TICKS_POR_VUELTA) * 2 * math.pi

def normalizar_grados(deg):
    return ((deg + 180) % 360) - 180

def aplicar_transformacion(ticks_list, signs, offsets):
    return [signs[i] * ticks_a_rad(t) + offsets[i]
            for i, t in enumerate(ticks_list)]

def wrap_centrado(q, centro):
    """Coloca q en el intervalo [centro-π, centro+π), moviendo el corte a centro+π."""
    return centro + (q - centro + math.pi) % (2 * math.pi) - math.pi

# ── Estado compartido ─────────────────────────────────────────────────────────
q_brazo1 = [0.0] * 6
q_brazo2 = [0.0] * 6
lock_q1  = threading.Lock()
lock_q2  = threading.Lock()
running  = True

# ── Inicializar ROS ───────────────────────────────────────────────────────────
rospy.init_node('gello_publisher', anonymous=True)
pub_right  = rospy.Publisher('/robot/left_arm/joint_states',  JointState, queue_size=1)
pub_left = rospy.Publisher('/robot/right_arm/joint_states', JointState, queue_size=1)

def make_joint_state_msg(q_reordenado, names):
    msg = JointState()
    msg.header.stamp = rospy.Time.now()
    msg.name     = names
    msg.position = q_reordenado
    msg.velocity = [0.0] * 6
    msg.effort   = [0.0] * 6
    return msg

# ── Inicializar comunicación Dynamixel ────────────────────────────────────────
def init_puerto(port):
    ph = PortHandler(port)
    pk = PacketHandler(PROTOCOL)
    if not ph.openPort():
        raise IOError(f"No se pudo abrir {port}")
    if not ph.setBaudRate(BAUDRATE):
        raise IOError(f"No se pudo configurar baudrate en {port}")
    print(f"✓ Conectado a {port}")
    return ph, pk

port_handler_1, packet_handler_1 = init_puerto(PORT_1)
port_handler_2, packet_handler_2 = init_puerto(PORT_2)

lock_port1 = threading.Lock()
lock_port2 = threading.Lock()

def leer_posicion(motor_id, port_handler, packet_handler, lock_port):
    try:
        with lock_port:
            pos, result, error = packet_handler.read4ByteTxRx(
                port_handler, motor_id, ADDR_PRESENT_POSITION)
        if result != 0 or error != 0:
            return None
        return pos
    except Exception:
        return None

# ── Hilos de lectura ──────────────────────────────────────────────────────────
def hilo_lectura(motor_ids, signs, offsets, port_handler, packet_handler,
                 lock_port, lock_q, q_ref, label):
    while running:
        try:
            ticks_list = []
            hay_error  = False
            for motor_id in motor_ids:
                pos = leer_posicion(motor_id, port_handler, packet_handler, lock_port)
                if pos is None:
                    hay_error = True
                    break
                ticks_list.append(pos)
            if not hay_error:
                q_nuevo = aplicar_transformacion(ticks_list, signs, offsets)
                with lock_q:
                    q_ref[:] = q_nuevo
        except Exception:
            pass

threading.Thread(
    target=hilo_lectura,
    args=(MOTOR_IDS_1, SIGNS_1, OFFSETS_1,
          port_handler_1, packet_handler_1,
          lock_port1, lock_q1, q_brazo1, "B1"),
    daemon=True
).start()

threading.Thread(
    target=hilo_lectura,
    args=(MOTOR_IDS_2, SIGNS_2, OFFSETS_2,
          port_handler_2, packet_handler_2,
          lock_port2, lock_q2, q_brazo2, "B2"),
    daemon=True
).start()

# ── Inicializar PyBullet (opcional, puedes comentar este bloque) ──────────────
p.connect(p.GUI)
p.setAdditionalSearchPath(pybullet_data.getDataPath())
p.setGravity(0, 0, 0)
p.resetDebugVisualizerCamera(1.8, 45, -30, [0, 0, 0.3])
p.loadURDF("plane.urdf")

rot_180y      = p.getQuaternionFromEuler([0, math.pi, 0])
rot_180y_180z = p.getQuaternionFromEuler([0, math.pi, math.pi])
robot_id_1 = p.loadURDF(URDF_PATH, basePosition=[-0.1, 0, 0.8], baseOrientation=rot_180y,      useFixedBase=True)
robot_id_2 = p.loadURDF(URDF_PATH, basePosition=[0.1, 0, 0.8], baseOrientation=rot_180y_180z, useFixedBase=True)

def get_joints_moviles(robot_id):
    return [i for i in range(p.getNumJoints(robot_id))
            if p.getJointInfo(robot_id, i)[2] == p.JOINT_REVOLUTE]

joints_1 = get_joints_moviles(robot_id_1)
joints_2 = get_joints_moviles(robot_id_2)

time.sleep(0.5)

# ── Bucle principal ───────────────────────────────────────────────────────────
try:
    while p.isConnected() and not rospy.is_shutdown():
        with lock_q1:
            q1 = list(q_brazo1)
            q1[0] = wrap_centrado(q1[0], math.pi)
            q1[1] = wrap_centrado(q1[1], math.radians(-13))
        with lock_q2:
            q2 = list(q_brazo2)

        # ── Publicar a ADAMSim via ROS ────────────────────────────────────────
        pub_left.publish(make_joint_state_msg(reorder_para_adamsim(q1), JOINT_NAMES_LEFT))
        pub_right.publish(make_joint_state_msg(reorder_para_adamsim(q2), JOINT_NAMES_RIGHT))

        # ── Actualizar PyBullet local ─────────────────────────────────────────
        for i, j in enumerate(joints_1[:6]):
            p.resetJointState(robot_id_1, j, q1[i])
        for i, j in enumerate(joints_2[:6]):
            p.resetJointState(robot_id_2, j, q2[i])

        b1 = "  ".join(f"J{i+1}:{normalizar_grados(math.degrees(q1[i])):>6.1f}°" for i in range(6))
        b2 = "  ".join(f"J{i+1}:{normalizar_grados(math.degrees(q2[i])):>6.1f}°" for i in range(6))
        print(f"B1: {b1}")
        print(f"B2: {b2}")

        p.stepSimulation()
        time.sleep(0.05)

except Exception as e:
    print(f"\nError: {e}")
finally:
    running = False
    time.sleep(0.2)
    port_handler_1.closePort()
    port_handler_2.closePort()
    print("\nPuertos cerrados.")