import math
import time
import threading
import pybullet as p
import pybullet_data
from dynamixel_sdk import PortHandler, PacketHandler
import rospy
import os
import sys
import numpy as np
import roboticstoolbox as rtb
from roboticstoolbox import RevoluteDH
from sensor_msgs.msg import JointState

# Importamos ADAMSim para cargar el robot en PyBullet y tener su ID y joints
sys.path.append(os.path.join(os.path.dirname(__file__), "AdamSim"))
from scripts.adam import ADAM

# URDF robot path and create ADAM instance
base_path = os.path.dirname(__file__)
robot_urdf_path = "/home/alumnos/tfg-laura/AdamSim/models/robot/rb1_base_description/robots/robotDummy.urdf"
adam = ADAM(robot_urdf_path, useRealTimeSimulation=True, used_fixed_base=True, use_ros=False)
print([a for a in dir(adam) if not a.startswith('_')])


# ════════════════════════════════════════════════════════════════════════════
#  CONFIGURACION DE LOS DOS BRAZOS
# ════════════════════════════════════════════════════════════════════════════
PORT_2      = "/dev/ttyUSB1"
MOTOR_IDS_2 = [1, 2, 3, 4, 5, 6]
SIGNS_2     = [1, 1, -1, 1, 1, 1]
OFFSETS_2 = [-2.8769, -4.4879, 3.0840, 3.2282, -3.0217, 1.5567]

PORT_1      = "/dev/ttyUSB0"
MOTOR_IDS_1 = [8, 9, 10, 11, 12, 13]
SIGNS_1     = [1, 1, -1, 1, 1, 1]
OFFSETS_1 = [-6.2262, -3.3671, 3.1002, -1.6222, -3.2817, -4.6493]

BAUDRATE  = 57600
PROTOCOL  = 2.0

ADDR_PRESENT_POSITION = 132
TICKS_POR_VUELTA      = 4096
ADDR_OPERATING_MODE   = 11
ADDR_TORQUE_ENABLE    = 64
ADDR_GOAL_CURRENT     = 102
CURRENT_CONTROL_MODE  = 0


# ════════════════════════════════════════════════════════════════════════════
#  GRAVITY COMPENSATION  (modelo + ajustes, de grav2.py)
# ════════════════════════════════════════════════════════════════════════════
M     = [0.041, 0.063, 0.065, 0.034, 0.030, 0.074]
A     = [0.0,   -0.135, -0.105, 0.0,    0.0,    0.0]
D     = [0.01,   0.0,    0.0,    0.04,   0.03,   0.02]
ALPHA = [math.pi/2, 0.0, 0.0, math.pi/2, -math.pi/2, 0.0]
R = [
    [0.0,  -0.010, 0.0],
    [0.072, 0.0,   0.064],
    [0.025, 0.0,   0.012],
    [0.0,   0.0,   0.005],
    [0.0,   0.0,   0.005],
    [0.0,   0.0,  -0.010],
]
_links = [RevoluteDH(a=A[i], d=D[i], alpha=ALPHA[i], m=M[i], r=R[i],
                     I=[1e-5, 1e-5, 1e-5, 0, 0, 0]) for i in range(6)]
robot = rtb.DHRobot(_links, name="gello_leader")

def gravedad_desde_angulos(tilt_deg, azimut_deg, g=9.81):
    t = math.radians(tilt_deg)
    a = math.radians(azimut_deg)
    return [g*math.sin(t)*math.cos(a), g*math.sin(t)*math.sin(a), g*math.cos(t)]

# ── Ajustes ───────────────────────────
GAIN        = 0.4
K_CURRENT   = 1500.0
MAX_CURRENT = 150

ACTIVO_1 = [1, 1, 1, 1, 0, 0]
ACTIVO_2 = [1, 1, 1, 1, 0, 0]

CURRENT_SIGN_1 = [-1, 1, 1, 1, 1, 1]
CURRENT_SIGN_2 = [-1, 1, 1, 1, 1, 1]

TILT_DEG = 45
AZIMUT_1 = 90
AZIMUT_2 = -90
GRAVEDAD_1 = gravedad_desde_angulos(TILT_DEG, AZIMUT_1)
GRAVEDAD_2 = gravedad_desde_angulos(TILT_DEG, AZIMUT_2)

USAR_J1_DIRECTO = False
J1_PICO_1 = 0
J1_AMP_1  = 0.15
J1_PICO_2 = 0
J1_AMP_2  = 0.15

ESCALA_1 = [1.0, 1.0, 1.0, 1.0, 1.0, 1.0]
ESCALA_2 = [1.0, 1.0, 1.0, 1.0, 1.0, 1.0]


def ticks_a_rad(ticks):
    ticks_norm = ticks % TICKS_POR_VUELTA
    return (ticks_norm / TICKS_POR_VUELTA) * 2 * math.pi

def normalizar_grados(deg):
    return ((deg + 180) % 360) - 180

def aplicar_transformacion(ticks_list, signs, offsets):
    return [signs[i] * ticks_a_rad(t) + offsets[i]
            for i, t in enumerate(ticks_list)]

def corriente_gravedad(q, signs, current_sign, activo, gravedad, escala, pico_j1, amp_j1):
    """De la posicion q (np.array) saca el par de gravedad -> corriente por motor."""
    tau = robot.gravload(q, gravity=gravedad)
    if USAR_J1_DIRECTO:
        tau[0] = amp_j1 * math.cos(q[0] - math.radians(pico_j1))
    corrientes = []
    for i in range(6):
        c = activo[i] * escala[i] * current_sign[i] * signs[i] * GAIN * K_CURRENT * tau[i]
        corrientes.append(int(np.clip(c, -MAX_CURRENT, MAX_CURRENT)))
    return corrientes


# ── Orden de joints que espera ADAMSim ──────────────────────────────────────
JOINT_NAMES_LEFT = [
    'robot_left_arm_elbow_joint', 'robot_left_arm_shoulder_lift_joint',
    'robot_left_arm_shoulder_pan_joint', 'robot_left_arm_wrist_1_joint',
    'robot_left_arm_wrist_2_joint', 'robot_left_arm_wrist_3_joint',
]
JOINT_NAMES_RIGHT = [
    'robot_right_arm_elbow_joint', 'robot_right_arm_shoulder_lift_joint',
    'robot_right_arm_shoulder_pan_joint', 'robot_right_arm_wrist_1_joint',
    'robot_right_arm_wrist_2_joint', 'robot_right_arm_wrist_3_joint',
]

def reorder_para_adamsim(q):
    return [q[2], q[1], q[0], q[3], q[4], q[5]]


# ── Estado compartido ───────────────────────────────────────────────────────
q_brazo1 = [0.0] * 6
q_brazo2 = [0.0] * 6
lock_q1  = threading.Lock()
lock_q2  = threading.Lock()
running  = True

# ── ROS ─────────────────────────────────────────────────────────────────────
rospy.init_node('gello_publisher', anonymous=True)
pub_right = rospy.Publisher('/robot/left_arm/joint_states',  JointState, queue_size=1)
pub_left  = rospy.Publisher('/robot/right_arm/joint_states', JointState, queue_size=1)

def make_joint_state_msg(q_reordenado, names):
    msg = JointState()
    msg.header.stamp = rospy.Time.now()
    msg.name     = names
    msg.position = q_reordenado
    msg.velocity = [0.0] * 6
    msg.effort   = [0.0] * 6
    return msg


# ── Dynamixel: abrir puertos ────────────────────────────────────────────────
def init_puerto(port):
    ph = PortHandler(port)
    pk = PacketHandler(PROTOCOL)
    if not ph.openPort():
        raise IOError(f"No se pudo abrir {port}")
    if not ph.setBaudRate(BAUDRATE):
        raise IOError(f"No se pudo configurar baudrate en {port}")
    print(f"✓ Conectado a {port}")
    return ph, pk

port_handler_1, packet_handler_1 = init_puerto(PORT_1)
port_handler_2, packet_handler_2 = init_puerto(PORT_2)

lock_port1 = threading.Lock()
lock_port2 = threading.Lock()

# ── Poner motores en modo corriente (para gravity comp) ─────────────────────
def configurar_corriente(port, packet, motor_ids, etiqueta):
    print(f"Configurando corriente en {etiqueta}:")
    for mid in motor_ids:
        packet.write1ByteTxRx(port, mid, ADDR_TORQUE_ENABLE, 0)
        time.sleep(0.02)
        modo_ok = False
        for _ in range(5):
            packet.write1ByteTxRx(port, mid, ADDR_OPERATING_MODE, CURRENT_CONTROL_MODE)
            time.sleep(0.03)
            modo, res, err = packet.read1ByteTxRx(port, mid, ADDR_OPERATING_MODE)
            if res == 0 and err == 0 and modo == CURRENT_CONTROL_MODE:
                modo_ok = True
                break
        packet.write2ByteTxRx(port, mid, ADDR_GOAL_CURRENT, 0)
        packet.write1ByteTxRx(port, mid, ADDR_TORQUE_ENABLE, 1)
        print(f"  ID {mid:2d}: {'OK modo corriente' if modo_ok else '!! NO cambio a corriente'}")

def escribir_corrientes(motor_ids, corrientes, port, packet, lock_port):
    with lock_port:
        for mid, c in zip(motor_ids, corrientes):
            packet.write2ByteTxRx(port, mid, ADDR_GOAL_CURRENT, int(c) & 0xFFFF)

def apagar(motor_ids, port, packet, lock_port):
    with lock_port:
        for mid in motor_ids:
            packet.write2ByteTxRx(port, mid, ADDR_GOAL_CURRENT, 0)
            packet.write1ByteTxRx(port, mid, ADDR_TORQUE_ENABLE, 0)


# ── Lectura de motores (hilos) ──────────────────────────────────────────────
def leer_posicion(motor_id, port_handler, packet_handler, lock_port):
    try:
        with lock_port:
            pos, result, error = packet_handler.read4ByteTxRx(
                port_handler, motor_id, ADDR_PRESENT_POSITION)
        if result != 0 or error != 0:
            return None
        return pos
    except Exception:
        return None

def hilo_lectura(motor_ids, signs, offsets, port_handler, packet_handler,
                 lock_port, lock_q, q_ref, label):
    while running:
        try:
            ticks_list = []
            hay_error  = False
            for motor_id in motor_ids:
                pos = leer_posicion(motor_id, port_handler, packet_handler, lock_port)
                if pos is None:
                    hay_error = True
                    break
                ticks_list.append(pos)
            if not hay_error:
                q_nuevo = aplicar_transformacion(ticks_list, signs, offsets)
                with lock_q:
                    q_ref[:] = q_nuevo
        except Exception:
            pass

# Poner los motores en modo corriente ANTES de arrancar los hilos (bus libre)
configurar_corriente(port_handler_1, packet_handler_1, MOTOR_IDS_1, "brazo 1 (USB0)")
configurar_corriente(port_handler_2, packet_handler_2, MOTOR_IDS_2, "brazo 2 (USB1)")

threading.Thread(
    target=hilo_lectura,
    args=(MOTOR_IDS_1, SIGNS_1, OFFSETS_1, port_handler_1, packet_handler_1,
          lock_port1, lock_q1, q_brazo1, "B1"), daemon=True).start()
threading.Thread(
    target=hilo_lectura,
    args=(MOTOR_IDS_2, SIGNS_2, OFFSETS_2, port_handler_2, packet_handler_2,
          lock_port2, lock_q2, q_brazo2, "B2"), daemon=True).start()

# ── Hilo de GRAVEDAD: calcula y manda corriente, aparte del bucle de ADAMSim ─
#   Va a su propio ritmo (~10 Hz). Suficiente: la gravedad cambia despacio y la
#   corriente se queda puesta en el motor hasta el siguiente envio.
GRAV_PERIODO = 0.08   # segundos entre recalculos (sube si quieres aliviar mas la CPU)

def hilo_gravedad():
    while running:
        try:
            with lock_q1:
                q1 = list(q_brazo1)
            with lock_q2:
                q2 = list(q_brazo2)
            c1 = corriente_gravedad(np.array(q1), SIGNS_1, CURRENT_SIGN_1, ACTIVO_1,
                                    GRAVEDAD_1, ESCALA_1, J1_PICO_1, J1_AMP_1)
            c2 = corriente_gravedad(np.array(q2), SIGNS_2, CURRENT_SIGN_2, ACTIVO_2,
                                    GRAVEDAD_2, ESCALA_2, J1_PICO_2, J1_AMP_2)
            escribir_corrientes(MOTOR_IDS_1, c1, port_handler_1, packet_handler_1, lock_port1)
            escribir_corrientes(MOTOR_IDS_2, c2, port_handler_2, packet_handler_2, lock_port2)
        except Exception:
            pass
        time.sleep(GRAV_PERIODO)

threading.Thread(target=hilo_gravedad, daemon=True).start()

print(f"\nGAIN={GAIN}  K_CURRENT={K_CURRENT}  MAX_CURRENT={MAX_CURRENT}")
print("Flotacion + teleoperacion ADAMSim activas. Ctrl+C para parar.\n")


# ════════════════════════════════════════════════════════════════════════════
#  BUCLE PRINCIPAL: teleoperar ADAMSim + flotacion a la vez
# ════════════════════════════════════════════════════════════════════════════
try:
    while p.isConnected() and not rospy.is_shutdown():
        with lock_q1:
            q1 = list(q_brazo1)
        with lock_q2:
            q2 = list(q_brazo2)

        # ── 1) TELEOPERACION: mover ADAMSim (rapido, sin nada que lo frene) ──
        adam.arm_kinematics.set_arm_pose('left',  'joint', q2)
        adam.arm_kinematics.set_arm_pose('right', 'joint', q1)

        # (La FLOTACION va en su propio hilo (hilo_gravedad), no aqui, para no
        #  frenar ADAMSim. El calculo de gravedad es pesado y la corriente que
        #  se manda a los motores se queda puesta hasta que se cambia.)

        b1 = "  ".join(f"J{i+1}:{normalizar_grados(math.degrees(q1[i])):>6.1f}°" for i in range(6))
        b2 = "  ".join(f"J{i+1}:{normalizar_grados(math.degrees(q2[i])):>6.1f}°" for i in range(6))
        print(f"B1: {b1}")
        print(f"B2: {b2}")

        time.sleep(0.05)

except Exception as e:
    print(f"\nError: {e}")
finally:
    running = False
    time.sleep(0.2)
    apagar(MOTOR_IDS_1, port_handler_1, packet_handler_1, lock_port1)
    apagar(MOTOR_IDS_2, port_handler_2, packet_handler_2, lock_port2)
    port_handler_1.closePort()
    port_handler_2.closePort()
    print("\nMotores libres, puertos cerrados.")