#!/usr/bin/env python3
# ============================================================================
#  Gravity compensation para los brazos GELLO  (inspirado en FACTR_Teleop)
#
#  Idea: en cada vuelta leemos la posicion de los motores, calculamos con un
#  modelo fisico (Pinocchio + gello_leader.urdf) cuanta fuerza hace falta para
#  sostener el brazo contra la gravedad, y la mandamos a los motores como
#  corriente. Resultado: el brazo "flota" y se mueve suave con un dedo.
#
#  ESTE SCRIPT ES SOLO GRAVITY COMP (sin ADAMSim). Es para ajustar primero la
#  flotacion. Cuando vaya bien, se mete en gello_v2_ADAM.py (ver el final).
# ============================================================================

import os
import time
import math
import numpy as np
import pinocchio as pin
from dynamixel_sdk import PortHandler, PacketHandler

# ── Modelo fisico del brazo (el plano que construimos) ──────────────────────
URDF_PATH = os.path.join(os.path.dirname(__file__), "gello_leader.urdf")
model, _, _ = pin.buildModelsFromUrdf(URDF_PATH)
data = model.createData()

# ── AJUSTES PRINCIPALES (esto es lo que vas a tocar) ────────────────────────
GAIN = 0.5            # 0.0 = sin ayuda (brazo suelto) ; 1.0 = compensa el 100%.
                      # Empieza en 0.0, sube poco a poco (0.3, 0.5, 0.8...).
                      # Quedate por debajo de 1.0 para que no derive hacia arriba.

K_CURRENT = 1500.0    # Conversion par->corriente (unidades de corriente por N*m).
                      # ESTE VALOR HAY QUE CALIBRARLO (ver instrucciones abajo).
                      # 1500 es un punto de partida conservador (compensa de menos).

MAX_CURRENT = 200     # Tope de corriente por motor (seguridad). No lo subas hasta
                      # que confirmes que cada junta ayuda en vez de pelear.

# Si una junta PELEA (empuja al lado contrario, vibra), pon -1 en su posicion:
CURRENT_SIGN = [1, 1, 1, 1, 1, 1]

# ── Configuracion de los dos brazos (igual que en gello_v2_ADAM.py) ─────────
PORT_2      = "/dev/ttyUSB0"
MOTOR_IDS_2 = [1, 2, 3, 4, 5, 6]
SIGNS_2     = [1, 1, -1, 1, 1, 1]
OFFSETS_2   = [-4.6222, -4.4879, 3.0840, 3.2282, -3.0217, 1.5567]

PORT_1      = "/dev/ttyUSB1"
MOTOR_IDS_1 = [8, 9, 10, 11, 12, 13]
SIGNS_1     = [1, 1, -1, 1, 1, 1]
OFFSETS_1   = [-3.0846, -3.3671, 3.1002, -1.6222, -3.2817, -4.6493]

BAUDRATE = 57600
PROTOCOL = 2.0
TICKS_POR_VUELTA = 4096

# Registros Dynamixel
ADDR_OPERATING_MODE   = 11
ADDR_TORQUE_ENABLE    = 64
ADDR_GOAL_CURRENT     = 102
ADDR_PRESENT_POSITION = 132
CURRENT_CONTROL_MODE  = 0


# ── Conversion ticks -> radianes en convencion del robot (= la del URDF) ────
def ticks_a_rad(ticks):
    return (ticks / TICKS_POR_VUELTA) * 2 * math.pi

def leer_q(motor_ids, signs, offsets, port, packet):
    """Lee los 6 motores de un brazo y devuelve q (rad) o None si falla."""
    q = []
    for i, mid in enumerate(motor_ids):
        pos, res, err = packet.read4ByteTxRx(port, mid, ADDR_PRESENT_POSITION)
        if res != 0 or err != 0:
            return None
        q.append(signs[i] * ticks_a_rad(pos) + offsets[i])
    return np.array(q)


# ── Calculo de gravedad ─────────────────────────────────────────────────────
def corriente_gravedad(q, signs):
    """De la posicion q saca el par de gravedad y lo pasa a corriente por motor."""
    tau = pin.computeGeneralizedGravity(model, data, q)   # N*m en cada junta
    corrientes = []
    for i in range(6):
        c = CURRENT_SIGN[i] * signs[i] * GAIN * K_CURRENT * tau[i]
        c = int(np.clip(c, -MAX_CURRENT, MAX_CURRENT))
        corrientes.append(c)
    return corrientes, tau


# ── Arranque de un puerto: modo corriente + torque ON ───────────────────────
def init_puerto(port_name, motor_ids):
    port = PortHandler(port_name)
    packet = PacketHandler(PROTOCOL)
    if not port.openPort():
        raise IOError(f"No se pudo abrir {port_name}")
    if not port.setBaudRate(BAUDRATE):
        raise IOError(f"No se pudo poner baudrate en {port_name}")
    for mid in motor_ids:
        # el modo solo se cambia con el torque apagado
        packet.write1ByteTxRx(port, mid, ADDR_TORQUE_ENABLE, 0)
        packet.write1ByteTxRx(port, mid, ADDR_OPERATING_MODE, CURRENT_CONTROL_MODE)
        packet.write1ByteTxRx(port, mid, ADDR_TORQUE_ENABLE, 1)
    print(f"✓ {port_name} en modo corriente, torque ON")
    return port, packet

def escribir_corrientes(motor_ids, corrientes, port, packet):
    for mid, c in zip(motor_ids, corrientes):
        packet.write2ByteTxRx(port, mid, ADDR_GOAL_CURRENT, int(c) & 0xFFFF)

def apagar(motor_ids, port, packet):
    for mid in motor_ids:
        packet.write2ByteTxRx(port, mid, ADDR_GOAL_CURRENT, 0)   # corriente 0
        packet.write1ByteTxRx(port, mid, ADDR_TORQUE_ENABLE, 0)  # torque off


# ── Programa principal ──────────────────────────────────────────────────────
def main():
    port1, packet1 = init_puerto(PORT_1, MOTOR_IDS_1)
    port2, packet2 = init_puerto(PORT_2, MOTOR_IDS_2)
    print(f"\nGAIN={GAIN}  K_CURRENT={K_CURRENT}  MAX_CURRENT={MAX_CURRENT}")
    print("Mueve los brazos con la mano. Ctrl+C para parar.\n")

    try:
        while True:
            for (ids, signs, offs, port, packet, lbl) in [
                (MOTOR_IDS_1, SIGNS_1, OFFSETS_1, port1, packet1, "B1"),
                (MOTOR_IDS_2, SIGNS_2, OFFSETS_2, port2, packet2, "B2"),
            ]:
                q = leer_q(ids, signs, offs, port, packet)
                if q is None:
                    continue
                corrientes, tau = corriente_gravedad(q, signs)
                escribir_corrientes(ids, corrientes, port, packet)

                # info en pantalla (par del modelo y corriente enviada)
                txt = "  ".join(f"J{i+1}:{tau[i]:+.3f}Nm/{corrientes[i]:+4d}"
                                for i in range(6))
                print(f"{lbl} {txt}")
            print("")
            time.sleep(0.02)

    except KeyboardInterrupt:
        print("\nParando, soltando motores...")
    finally:
        apagar(MOTOR_IDS_1, port1, packet1)
        apagar(MOTOR_IDS_2, port2, packet2)
        port1.closePort()
        port2.closePort()
        print("Motores libres, puertos cerrados.")


if __name__ == "__main__":
    main()
