from dynamixel_sdk import PortHandler, PacketHandler
import time

PORT = "/dev/ttyUSB0"
DXL_ID = 11          # un motor de muñeca, poca masa = más seguro
BAUD = 57600

ADDR_OPERATING_MODE  = 11   # 0 = control de corriente
ADDR_TORQUE_ENABLE   = 64
ADDR_GOAL_CURRENT    = 102  # 2 bytes
ADDR_PRESENT_CURRENT = 126  # 2 bytes

ph = PortHandler(PORT); pk = PacketHandler(2.0)
ph.openPort(); ph.setBaudRate(BAUD)

pk.write1ByteTxRx(ph, DXL_ID, ADDR_TORQUE_ENABLE, 0)     # torque OFF para cambiar modo
pk.write1ByteTxRx(ph, DXL_ID, ADDR_OPERATING_MODE, 0)    # modo corriente
pk.write1ByteTxRx(ph, DXL_ID, ADDR_TORQUE_ENABLE, 1)     # torque ON

pk.write2ByteTxRx(ph, DXL_ID, ADDR_GOAL_CURRENT, 8)      # empujón pequeñito (~unidades, NO mA aún)

try:
    while True:
        cur, _, _ = pk.read2ByteTxRx(ph, DXL_ID, ADDR_PRESENT_CURRENT)
        if cur > 32767: cur -= 65536        # valor con signo
        print(f"Corriente actual: {cur}")
        time.sleep(0.1)
except KeyboardInterrupt:
    pass
finally:
    pk.write2ByteTxRx(ph, DXL_ID, ADDR_GOAL_CURRENT, 0)
    pk.write1ByteTxRx(ph, DXL_ID, ADDR_TORQUE_ENABLE, 0)
    ph.closePort()