import math
import time
import threading
import pybullet as p
import os
import sys
import numpy as np

# PyKDL para la dinámica
import PyKDL as kdl
from kdl_parser_py.urdf import treeFromFile

# Importamos ADAMSim
sys.path.append(os.path.join(os.path.dirname(__file__), "AdamSim"))
from scripts.adam import ADAM

from dynamixel_sdk import PortHandler, PacketHandler, GroupSyncRead, GroupSyncWrite

# URDF robot path and create ADAM instance
base_path = os.path.dirname(__file__)
robot_urdf_path = "/home/alumnos/tfg-laura/AdamSim/models/robot/rb1_base_description/robots/robotDummy.urdf"
adam = ADAM(robot_urdf_path, useRealTimeSimulation=True, used_fixed_base=True, use_ros=False)

# ════════════════════════════════════════════════════════════════════════════
#  CLASE DE COMPENSACIÓN DE GRAVEDAD (KDL)
# ════════════════════════════════════════════════════════════════════════════
class GravityCompensationKDL:
    def __init__(self, urdf_path, root_name, tip_name, gravity_vector):
        success, self.tree = treeFromFile(urdf_path)
        if not success:
            raise RuntimeError(f"No se pudo cargar el URDF en PyKDL: {urdf_path}")
        
        self.chain = self.tree.getChain(root_name, tip_name)
        self.num_joints = self.chain.getNrOfJoints()
        
        if self.num_joints != 6:
            print(f"[Aviso] KDL detectó {self.num_joints} joints entre {root_name} y {tip_name} en lugar de 6.")

        # Vector de gravedad
        self.gravity = kdl.Vector(gravity_vector[0], gravity_vector[1], gravity_vector[2])
        self.dyn_solver = kdl.ChainDynParam(self.chain, self.gravity)

        self.q_kdl = kdl.JntArray(self.num_joints)
        self.G_kdl = kdl.JntArray(self.num_joints)

    def compute_gravity_torque(self, current_q):
        for i in range(self.num_joints):
            self.q_kdl[i] = current_q[i]
            
        # JntToGravity calcula SOLO las fuerzas gravitacionales estáticas
        self.dyn_solver.JntToGravity(self.q_kdl, self.G_kdl)
        return [self.G_kdl[i] for i in range(self.num_joints)]

# ── Cadenas extraídas directamente del robotDummy.urdf ──
LINK_BASE_1 = "rb1_right_arm_base_link" 
LINK_TIP_1  = "rb1_right_arm_tool0" 

LINK_BASE_2 = "rb1_left_arm_base_link"
LINK_TIP_2  = "rb1_left_arm_tool0"

GRAVEDAD_1 = [6.936, 0.0, 6.936] 
GRAVEDAD_2 = [6.936, 0.0, 6.936] 

kdl_solver_1 = GravityCompensationKDL(robot_urdf_path, LINK_BASE_1, LINK_TIP_1, GRAVEDAD_1)
kdl_solver_2 = GravityCompensationKDL(robot_urdf_path, LINK_BASE_2, LINK_TIP_2, GRAVEDAD_2)

# ════════════════════════════════════════════════════════════════════════════
#  CONFIGURACION DE LOS DOS BRAZOS
# ════════════════════════════════════════════════════════════════════════════
PORT_2      = "/dev/ttyUSB1"
MOTOR_IDS_2 = [1, 2, 3, 4, 5, 6]
SIGNS_2     = [1, 1, -1, 1, 1, 1]
OFFSETS_2 = [-2.8769, -4.4879, 3.0840, 3.2282, -3.0217, 1.5567]

PORT_1      = "/dev/ttyUSB0"
MOTOR_IDS_1 = [8, 9, 10, 11, 12, 13]
SIGNS_1     = [1, 1, -1, 1, 1, 1]
OFFSETS_1 = [-6.2262, -3.3671, 3.1002, -1.6222, -3.2817, -4.6493]

BAUDRATE  = 57600
PROTOCOL  = 2.0
ADDR_OPERATING_MODE   = 11
ADDR_TORQUE_ENABLE    = 64
ADDR_GOAL_CURRENT     = 102
ADDR_GOAL_POSITION    = 116  
ADDR_PRESENT_POSITION = 132
TICKS_POR_VUELTA      = 4096
MODE_CURRENT_BASED_POSITION = 5

GAIN        = 1.2
K_CURRENT   = 1500.0
MAX_CURRENT = 700           
MAX_CURRENT_MOV  = 100
MAX_CURRENT_HOLD = [500, 500, 350, 220, 160, 160]
MARGEN_AGARRE    = [220, 220, 120,  40,  20,  20]
UMBRAL_ENTRAR = [ 35,  35,  35,  20,  12,  12]
UMBRAL_SALIR  = [ 20,  20,  12,   8,   5,   5]

ACTIVO_1 = [1, 1, 1, 1, 0, 0]
ACTIVO_2 = [1, 1, 1, 1, 0, 0]
CURRENT_SIGN_1 = [-1, -1, 1, 1, 1, 1]
CURRENT_SIGN_2 = [-1, -1, 1, 1, 1, 1]
ESCALA_1 = [4.5,  6.5,  0.0,  0.1,  0.1,  0.1]
ESCALA_2 = [4.5,  6.5,  0.0,  0.1,  0.1,  0.1]

# ── Estado compartido ───────────────────────────────────────────────────────
q_brazo1 = [0.0] * 6
q_brazo2 = [0.0] * 6
ticks_actuales_1 = [0] * 6
ticks_actuales_2 = [0] * 6
lock_q1  = threading.Lock()
lock_q2  = threading.Lock()
running  = True

def ticks_a_rad(ticks):
    return ((ticks % TICKS_POR_VUELTA) / TICKS_POR_VUELTA) * 2 * math.pi

def normalizar_grados(deg):
    return ((deg + 180) % 360) - 180

def aplicar_transformacion(ticks_list, signs, offsets):
    return [signs[i] * ticks_a_rad(t) + offsets[i] for i, t in enumerate(ticks_list)]

def corriente_estatica_kdl(tau, signs, current_sign, activo, escala):
    corrientes = []
    for i in range(6):
        c = activo[i] * escala[i] * current_sign[i] * signs[i] * GAIN * K_CURRENT * tau[i]
        corrientes.append(int(np.clip(c, -MAX_CURRENT, MAX_CURRENT)))
    return corrientes

# ── Inicialización Dynamixel ────────────────────────────────────────────────
def init_puerto(port):
    ph = PortHandler(port)
    pk = PacketHandler(PROTOCOL)
    if not ph.openPort(): raise IOError(f"No se pudo abrir {port}")
    if not ph.setBaudRate(BAUDRATE): raise IOError(f"No se pudo configurar baudrate en {port}")
    return ph, pk

port_handler_1, packet_handler_1 = init_puerto(PORT_1)
port_handler_2, packet_handler_2 = init_puerto(PORT_2)

sync_read_1 = GroupSyncRead(port_handler_1, packet_handler_1, ADDR_PRESENT_POSITION, 4)
sync_read_2 = GroupSyncRead(port_handler_2, packet_handler_2, ADDR_PRESENT_POSITION, 4)
sync_write_cur_1 = GroupSyncWrite(port_handler_1, packet_handler_1, ADDR_GOAL_CURRENT, 2)
sync_write_pos_1 = GroupSyncWrite(port_handler_1, packet_handler_1, ADDR_GOAL_POSITION, 4)
sync_write_cur_2 = GroupSyncWrite(port_handler_2, packet_handler_2, ADDR_GOAL_CURRENT, 2)
sync_write_pos_2 = GroupSyncWrite(port_handler_2, packet_handler_2, ADDR_GOAL_POSITION, 4)

for mid in MOTOR_IDS_1: sync_read_1.addParam(mid)
for mid in MOTOR_IDS_2: sync_read_2.addParam(mid)

lock_port1 = threading.Lock()
lock_port2 = threading.Lock()

def configurar_modo5(port, packet, motor_ids, etiqueta):
    print(f"Configurando MODO 5 en {etiqueta}:")
    for mid in motor_ids:
        packet.write1ByteTxRx(port, mid, ADDR_TORQUE_ENABLE, 0)
        time.sleep(0.02)
        packet.write1ByteTxRx(port, mid, ADDR_OPERATING_MODE, MODE_CURRENT_BASED_POSITION)
        time.sleep(0.03)
        packet.write2ByteTxRx(port, mid, ADDR_GOAL_CURRENT, 0)
        packet.write1ByteTxRx(port, mid, ADDR_TORQUE_ENABLE, 1)

def apagar(motor_ids, port, packet, lock_port):
    with lock_port:
        for mid in motor_ids:
            packet.write2ByteTxRx(port, mid, ADDR_GOAL_CURRENT, 0)
            packet.write1ByteTxRx(port, mid, ADDR_TORQUE_ENABLE, 0)

# ── Hilo de Lectura Sincronizada ────────────────────────────────────────────
def hilo_lectura_sync(motor_ids, signs, offsets, sync_read, lock_port, lock_q, q_ref, ticks_ref):
    while running:
        try:
            with lock_port:
                res = sync_read.txRxPacket()
            if res == 0:
                t_list = []
                for mid in motor_ids:
                    if sync_read.isAvailable(mid, ADDR_PRESENT_POSITION, 4):
                        pos = sync_read.getData(mid, ADDR_PRESENT_POSITION, 4)
                        if pos > 0x7FFFFFFF: pos -= 0x100000000
                        t_list.append(pos)
                
                if len(t_list) == 6:
                    q_nuevo = aplicar_transformacion(t_list, signs, offsets)
                    with lock_q:
                        q_ref[:] = q_nuevo
                        ticks_ref[:] = t_list
        except Exception:
            pass
        time.sleep(0.01)

configurar_modo5(port_handler_1, packet_handler_1, MOTOR_IDS_1, "Brazo 1 (USB0)")
configurar_modo5(port_handler_2, packet_handler_2, MOTOR_IDS_2, "Brazo 2 (USB1)")

threading.Thread(target=hilo_lectura_sync, args=(MOTOR_IDS_1, SIGNS_1, OFFSETS_1, sync_read_1, lock_port1, lock_q1, q_brazo1, ticks_actuales_1), daemon=True).start()
threading.Thread(target=hilo_lectura_sync, args=(MOTOR_IDS_2, SIGNS_2, OFFSETS_2, sync_read_2, lock_port2, lock_q2, q_brazo2, ticks_actuales_2), daemon=True).start()

# ── Lógica del Embrague Reforzado (CON SUAVIZADO INDEPENDIENTE) ────────────
def procesar_embrague_suavizado(motor_ids, ticks_actuales, ticks_anteriores, locked_ticks, mov_state,
                                corrientes_aplicadas, corrientes_calculadas, sync_cur, sync_pos, lock_port):
    sync_cur.clearParam()
    sync_pos.clearParam()
    
    # FACTOR DE SUAVIZADO (0.0 = ignora nuevo, 1.0 = cambio instantáneo)
    # 0.4 crea una rampa suave de unos ~80ms que elimina los tirones musculares.
    ALPHA_CUR = 1.0 
    
    for i, mid in enumerate(motor_ids):
        vel = abs(ticks_actuales[i] - ticks_anteriores[i])
        
        # 1. MÁQUINA DE ESTADOS ESTRICTA (Garantiza que sujete al soltar)
        if mov_state[i]:
            if vel < UMBRAL_SALIR[i]:
                mov_state[i] = 0          
        else:
            if vel > UMBRAL_ENTRAR[i]:
                mov_state[i] = 1          
        
        # 2. DEFINIR OBJETIVOS BASADOS EN EL ESTADO
        if mov_state[i]:
            locked_ticks[i] = ticks_actuales[i] # Te sigue siempre que te mueves
            target_current = min(abs(int(corrientes_calculadas[i])), MAX_CURRENT_MOV)
        else:
            target_current = min(abs(int(corrientes_calculadas[i])) + MARGEN_AGARRE[i], MAX_CURRENT_HOLD[i])
        
        # 3. FILTRO PASO-BAJO PARA LA CORRIENTE (Elimina el tirón al cambiar de estado)
        corrientes_aplicadas[i] = int((ALPHA_CUR * target_current) + ((1.0 - ALPHA_CUR) * corrientes_aplicadas[i]))
        goal_current = corrientes_aplicadas[i]
        
        # 4. PREPARAR PAQUETES
        param_cur = [goal_current & 0xFF, (goal_current >> 8) & 0xFF]
        pos_int = int(locked_ticks[i]) & 0xFFFFFFFF
        param_pos = [pos_int & 0xFF, (pos_int >> 8) & 0xFF, (pos_int >> 16) & 0xFF, (pos_int >> 24) & 0xFF]
        
        sync_cur.addParam(mid, param_cur)
        sync_pos.addParam(mid, param_pos)
        
        ticks_anteriores[i] = ticks_actuales[i]

    with lock_port:
        sync_pos.txPacket()
        sync_cur.txPacket()

GRAV_PERIODO = 0.02

# ── Hilo de Control Dinámico (Optimizado PyKDL) ─────────────────────────────
def hilo_dinamica_embrague():
    last_t1 = [0]*6; locked_t1 = [0]*6; mov_state_1 = [0]*6; cur_aplicada_1 = [0]*6
    last_t2 = [0]*6; locked_t2 = [0]*6; mov_state_2 = [0]*6; cur_aplicada_2 = [0]*6
    
    time.sleep(0.5)
    with lock_q1: 
        last_t1[:] = ticks_actuales_1; locked_t1[:] = ticks_actuales_1
    with lock_q2: 
        last_t2[:] = ticks_actuales_2; locked_t2[:] = ticks_actuales_2

    while running:
        try:
            with lock_q1:
                q1 = list(q_brazo1); t1 = list(ticks_actuales_1)
            with lock_q2:
                q2 = list(q_brazo2); t2 = list(ticks_actuales_2)
            
            tau_1 = kdl_solver_1.compute_gravity_torque(q1)
            tau_2 = kdl_solver_2.compute_gravity_torque(q2)
                
            c1 = corriente_estatica_kdl(tau_1, SIGNS_1, CURRENT_SIGN_1, ACTIVO_1, ESCALA_1)
            c2 = corriente_estatica_kdl(tau_2, SIGNS_2, CURRENT_SIGN_2, ACTIVO_2, ESCALA_2)
            
            procesar_embrague_suavizado(MOTOR_IDS_1, t1, last_t1, locked_t1, mov_state_1, cur_aplicada_1, c1, sync_write_cur_1, sync_write_pos_1, lock_port1)
            procesar_embrague_suavizado(MOTOR_IDS_2, t2, last_t2, locked_t2, mov_state_2, cur_aplicada_2, c2, sync_write_cur_2, sync_write_pos_2, lock_port2)
            
        except Exception as e:
            pass
            
        time.sleep(GRAV_PERIODO)

threading.Thread(target=hilo_dinamica_embrague, daemon=True).start()
print("\n[+] Sistema Activo: PyKDL + Embrague Suave LPF. Ctrl+C para salir.\n")

# ════════════════════════════════════════════════════════════════════════════
#  BUCLE PRINCIPAL (ADAMSim Sync)
# ════════════════════════════════════════════════════════════════════════════
try:
    while p.isConnected():
        with lock_q1: q1 = list(q_brazo1)
        with lock_q2: q2 = list(q_brazo2)

        adam.arm_kinematics.set_arm_pose('right', 'joint', q1)
        adam.arm_kinematics.set_arm_pose('left',  'joint', q2)

        b1 = "  ".join(f"J{i+1}:{normalizar_grados(math.degrees(q1[i])):>6.1f}°" for i in range(6))
        b2 = "  ".join(f"J{i+1}:{normalizar_grados(math.degrees(q2[i])):>6.1f}°" for i in range(6))
        print(f"B1 (Der): {b1}")
        print(f"B2 (Izq): {b2}")
        time.sleep(0.05)

except KeyboardInterrupt:
    print("\nDeteniendo el sistema manualmente...")
except Exception as e:
    print(f"\nError en Bucle Principal: {e}")
finally:
    running = False
    time.sleep(0.2)
    apagar(MOTOR_IDS_1, port_handler_1, packet_handler_1, lock_port1)
    apagar(MOTOR_IDS_2, port_handler_2, packet_handler_2, lock_port2)
    port_handler_1.closePort()
    port_handler_2.closePort()
    print("\nMotores liberados correctamente.")