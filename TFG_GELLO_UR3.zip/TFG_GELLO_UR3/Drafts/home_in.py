#!/usr/bin/env python3
"""
Home-in (visualización + gate visual): en ADAMSim
  - Brazos REALES de ADAM (topic ROS)  -> robot sólido.
  - GELLO (Dynamixel)                  -> copia translúcida (fantasma).
  - Un letrero por brazo que se pone VERDE cuando el fantasma coincide con el
    real dentro de ±TOL_DEG grados en todas las juntas.

Puntos clave:
  * Desenrollado temporal del GELLO (wrap_centrado contra el valor continuo
    anterior): elimina los saltos de 2π al cruzar el límite de vuelta, para
    que no se produzca la "vuelta entera brusca" que dañaría el robot real.
  * Gravedad apagada (visualizador).
  * Comparación del gate con diferencia envuelta a ±π: una vuelta completa
    cuenta como misma pose.

Órdenes de junta:
  - Topic ROS publica:  [elbow, lift, pan, w1, w2, w3]  (orden robot real)
  - set_arm_pose / GELLO usan: [pan, lift, elbow, w1, w2, w3]  (SIM_ORDER)
"""

import os
import sys
import math
import time
import threading

import rospy
import pybullet as p
from sensor_msgs.msg import JointState
from dynamixel_sdk import PortHandler, PacketHandler

# ── Cargar ADAMSim ────────────────────────────────────────────────────────────
sys.path.append(os.path.join(os.path.dirname(__file__), "AdamSim"))
from scripts.adam import ADAM

ROBOT_URDF_PATH = "/home/alumnos/tfg-laura/AdamSim/models/robot/rb1_base_description/robots/robotDummy.urdf"

# ── Config Dynamixel (de Simulacion_sin_gravity.py) ───────────────────────────
PORT_2      = "/dev/ttyUSB0"
MOTOR_IDS_2 = [1, 2, 3, 4, 5, 6]
SIGNS_2     = [1, 1, -1, 1, 1, 1]
OFFSETS_2   = [-4.4477, -4.4879, 3.0840, 3.2282, -3.0217, 1.5567]

PORT_1      = "/dev/ttyUSB1"
MOTOR_IDS_1 = [8, 9, 10, 11, 12, 13]
SIGNS_1     = [1, 1, -1, 1, 1, 1]
OFFSETS_1   = [-6.2262, -2.8435, 3.1002, -1.6222, -3.2817, -4.6493]

GELLO_MAP = {
    'left':  dict(port=PORT_2, ids=MOTOR_IDS_2, signs=SIGNS_2, offsets=OFFSETS_2),
    'right': dict(port=PORT_1, ids=MOTOR_IDS_1, signs=SIGNS_1, offsets=OFFSETS_1),
}

BAUDRATE  = 57600
PROTOCOL  = 2.0
ADDR_PRESENT_POSITION = 132
TICKS_POR_VUELTA      = 4096

# ── Órdenes / parámetros ──────────────────────────────────────────────────────
SIM_ORDER = [
    'shoulder_pan_joint',
    'shoulder_lift_joint',
    'elbow_joint',
    'wrist_1_joint',
    'wrist_2_joint',
    'wrist_3_joint',
]
LABELS = ['pan', 'lift', 'elbow', 'w1', 'w2', 'w3']

TOL_DEG     = 10.0                       # tolerancia del gate por junta
GHOST_COLOR = [0.35, 0.75, 1.0, 0.45]   # azul claro translúcido
GHOST_FORCE = 200.0

COLOR_OK    = [0.10, 0.90, 0.10]        # verde
COLOR_NO    = [0.95, 0.45, 0.10]        # naranja
COLOR_WAIT  = [0.60, 0.60, 0.60]        # gris


# ── Conversión / envoltura ────────────────────────────────────────────────────
def ticks_a_rad(ticks):
    ticks_norm = ticks % TICKS_POR_VUELTA
    return (ticks_norm / TICKS_POR_VUELTA) * 2 * math.pi

def aplicar_transformacion(ticks_list, signs, offsets):
    return [signs[i] * ticks_a_rad(t) + offsets[i] for i, t in enumerate(ticks_list)]

def wrap_centrado(q, centro):
    """Coloca q en [centro-π, centro+π): representante de q más cercano a centro."""
    return centro + (q - centro + math.pi) % (2 * math.pi) - math.pi

def wrap_a_pi(x):
    """Envuelve un ángulo a [-π, π)."""
    return (x + math.pi) % (2 * math.pi) - math.pi


# ── Detección de juntas de brazo por sufijo UR ────────────────────────────────
def detectar_brazos(body):
    grupos = {}
    for j in range(p.getNumJoints(body)):
        name = p.getJointInfo(body, j)[1].decode()
        for suf in SIM_ORDER:
            if name.endswith(suf):
                prefijo = name[:-len(suf)]
                grupos.setdefault(prefijo, {})[suf] = (j, name)
                break

    completos = {pre: d for pre, d in grupos.items() if len(d) == len(SIM_ORDER)}
    if len(completos) < 2:
        raise RuntimeError(
            f"No se detectaron 2 brazos UR completos. Prefijos: "
            f"{ {pre: list(d) for pre, d in grupos.items()} }")

    asign = {}
    for pre in completos:
        low = pre.lower()
        if 'left' in low:
            asign['left'] = pre
        elif 'right' in low:
            asign['right'] = pre
    if set(asign) != {'left', 'right'}:
        pres = list(completos)
        ys = {pre: p.getLinkState(body, completos[pre]['shoulder_pan_joint'][0])[0][1]
              for pre in pres}
        asign = {'left': max(pres, key=lambda pr: ys[pr]),
                 'right': min(pres, key=lambda pr: ys[pr])}
        print("[AVISO] left/right por geometría (y). Verifícalo visualmente.")

    idx, nombres = {}, {}
    for arm, pre in asign.items():
        idx[arm]     = [completos[pre][suf][0] for suf in SIM_ORDER]
        nombres[arm] = [completos[pre][suf][1] for suf in SIM_ORDER]
    return idx, nombres


# ══════════════════════════════════════════════════════════════════════════════
class Fantasma:
    def __init__(self, urdf_path, base_pos, base_orn):
        self.body = p.loadURDF(urdf_path, base_pos, base_orn, useFixedBase=True)

        p.changeVisualShape(self.body, -1, rgbaColor=GHOST_COLOR)
        p.setCollisionFilterGroupMask(self.body, -1, 0, 0)
        for j in range(p.getNumJoints(self.body)):
            p.changeVisualShape(self.body, j, rgbaColor=GHOST_COLOR)
            p.setCollisionFilterGroupMask(self.body, j, 0, 0)
            q = p.getJointState(self.body, j)[0]
            p.setJointMotorControl2(self.body, j, p.POSITION_CONTROL,
                                    targetPosition=q, force=GHOST_FORCE)

        self.arm_joint_idx, nombres = detectar_brazos(self.body)
        print("[Fantasma] Juntas de brazo detectadas:")
        for arm in ('left', 'right'):
            print(f"    {arm:>5}: {nombres[arm]}")

    def set_arm(self, arm, q_sim):
        p.setJointMotorControlArray(
            self.body, self.arm_joint_idx[arm], p.POSITION_CONTROL,
            targetPositions=q_sim, forces=[GHOST_FORCE] * 6)


# ══════════════════════════════════════════════════════════════════════════════
class VisualizadorFantasma:
    def __init__(self, urdf_path=ROBOT_URDF_PATH):
        rospy.init_node('home_in', anonymous=True)

        self.adam = ADAM(urdf_path, useRealTimeSimulation=True,
                         used_fixed_base=True, use_ros=False)
        p.setGravity(0, 0, 0)

        base_pos, base_orn = self._base_de_adam()   # setea self.adam_id
        self.fantasma = Fantasma(urdf_path, base_pos, base_orn)

        self._real = {'left': None, 'right': None}
        self._lock_real = threading.Lock()
        self._gello = {'left': None, 'right': None}
        self._lock_gello = threading.Lock()
        self._running = True

        rospy.Subscriber('/robot/left_arm/joint_states', JointState,
                         self._cb_real, callback_args='left', queue_size=1)
        rospy.Subscriber('/robot/right_arm/joint_states', JointState,
                         self._cb_real, callback_args='right', queue_size=1)

        self._ports = {}
        self._arrancar_gello()

        self._crear_letreros()
        rospy.loginfo("Visualizador listo. Esperando datos de topic y GELLO...")

    # ── Base de ADAM ───────────────────────────────────────────────────────────
    def _base_de_adam(self):
        adam_id = None
        for attr in ('robot_id', 'robotId', 'robot', 'id', 'uid', 'body_id'):
            val = getattr(self.adam, attr, None)
            if isinstance(val, int):
                adam_id = val
                break
        if adam_id is None:
            mejor, njmax = None, -1
            for b in range(p.getNumBodies()):
                uid = p.getBodyUniqueId(b)
                nj = p.getNumJoints(uid)
                if nj > njmax:
                    njmax, mejor = nj, uid
            adam_id = mejor
        self.adam_id = adam_id
        return p.getBasePositionAndOrientation(adam_id)

    # ── Topic ──────────────────────────────────────────────────────────────────
    def _cb_real(self, msg, arm):
        with self._lock_real:
            self._real[arm] = dict(zip(msg.name, msg.position))

    def _q_real_sim(self, arm):
        with self._lock_real:
            estado = self._real[arm]
            estado = dict(estado) if estado is not None else None
        if estado is None:
            return None
        pref = f'robot_{arm}_arm_'
        try:
            return [estado[pref + n] for n in SIM_ORDER]
        except KeyError:
            return None

    # ── GELLO (con desenrollado temporal) ──────────────────────────────────────
    def _arrancar_gello(self):
        for arm, cfg in GELLO_MAP.items():
            ph = PortHandler(cfg['port'])
            pk = PacketHandler(PROTOCOL)
            if not ph.openPort():
                raise IOError(f"No se pudo abrir {cfg['port']}")
            if not ph.setBaudRate(BAUDRATE):
                raise IOError(f"No se pudo configurar baudrate en {cfg['port']}")
            rospy.loginfo(f"✓ GELLO conectado a {cfg['port']} -> lado '{arm}'")
            lock_port = threading.Lock()
            self._ports[arm] = (ph, lock_port)
            threading.Thread(target=self._hilo_gello,
                             args=(arm, cfg, ph, pk, lock_port),
                             daemon=True).start()

    def _hilo_gello(self, arm, cfg, ph, pk, lock_port):
        ids, signs, offsets = cfg['ids'], cfg['signs'], cfg['offsets']
        q_prev = None   # valor continuo anterior (por junta) para desenrollar
        while self._running:
            try:
                ticks, err = [], False
                for mid in ids:
                    with lock_port:
                        pos, res, e = pk.read4ByteTxRx(ph, mid, ADDR_PRESENT_POSITION)
                    if res != 0 or e != 0:
                        err = True
                        break
                    ticks.append(pos)
                if err:
                    continue

                q_raw = aplicar_transformacion(ticks, signs, offsets)

                # Desenrollado temporal: cada junta se coloca a ±π del valor
                # continuo anterior -> sin saltos de 2π (no hay vuelta brusca).
                if q_prev is None:
                    q_cont = list(q_raw)
                else:
                    q_cont = [wrap_centrado(q_raw[i], q_prev[i]) for i in range(6)]
                q_prev = q_cont

                with self._lock_gello:
                    self._gello[arm] = q_cont
            except Exception:
                pass

    def _q_gello(self, arm):
        with self._lock_gello:
            q = self._gello[arm]
            return list(q) if q is not None else None

    # ── Gate: estado de alineación por brazo ───────────────────────────────────
    def _estado_arm(self, arm):
        q_real = self._q_real_sim(arm)
        q_gello = self._q_gello(arm)
        if q_real is None or q_gello is None:
            return None
        difs = [math.degrees(wrap_a_pi(g - r)) for g, r in zip(q_gello, q_real)]
        max_abs = max(abs(d) for d in difs)
        return dict(q_real=q_real, q_gello=q_gello, difs=difs,
                    max_abs=max_abs, aligned=max_abs <= TOL_DEG)

    # ── Letreros ───────────────────────────────────────────────────────────────
    def _crear_letreros(self):
        self._label_id = {}
        for arm in ('left', 'right'):
            pos = self._pos_letrero(arm)
            self._label_id[arm] = p.addUserDebugText(
                f"{arm.upper()}: ...", pos, textColorRGB=COLOR_WAIT, textSize=1.5)

    def _pos_letrero(self, arm):
        pan_idx = self.fantasma.arm_joint_idx[arm][0]  # 'shoulder_pan_joint'
        try:
            wp = p.getLinkState(self.adam_id, pan_idx)[0]
            return [wp[0], wp[1], wp[2] + 0.40]
        except Exception:
            return [0, 0.3 if arm == 'left' else -0.3, 1.6]

    def _actualizar_letreros(self):
        for arm in ('left', 'right'):
            est = self._estado_arm(arm)
            if est is None:
                texto, color = f"{arm.upper()}: sin datos", COLOR_WAIT
            elif est['aligned']:
                texto, color = f"{arm.upper()}: LISTO", COLOR_OK
            else:
                texto, color = f"{arm.upper()}: alinea  dmax={est['max_abs']:.0f} deg", COLOR_NO
            p.addUserDebugText(texto, self._pos_letrero(arm),
                               textColorRGB=color, textSize=1.5,
                               replaceItemUniqueId=self._label_id[arm])

    # ── Actualización ──────────────────────────────────────────────────────────
    def _actualizar(self):
        for arm in ('left', 'right'):
            q_real = self._q_real_sim(arm)
            if q_real is not None:
                self.adam.arm_kinematics.set_arm_pose(arm, 'joint', q_real)
            q_gello = self._q_gello(arm)
            if q_gello is not None:
                self.fantasma.set_arm(arm, q_gello)
        self._actualizar_letreros()

    # ── Impresión ──────────────────────────────────────────────────────────────
    def _imprimir(self):
        lineas = []
        for arm in ('left', 'right'):
            est = self._estado_arm(arm)
            marca = "LISTO" if (est and est['aligned']) else ""
            lineas.append(f"{arm.upper():<6} {marca:>6}   real(°)   gello(°)   d(°)")
            q_real = self._q_real_sim(arm)
            q_gello = self._q_gello(arm)
            for i, etq in enumerate(LABELS):
                r = q_real[i] if q_real else None
                g = q_gello[i] if q_gello else None
                rr = f"{math.degrees(r):>8.1f}" if r is not None else "     --"
                gg = f"{math.degrees(g):>8.1f}" if g is not None else "     --"
                if r is not None and g is not None:
                    d = math.degrees(wrap_a_pi(g - r))
                    flag = " " if abs(d) <= TOL_DEG else "*"
                    dd = f"{d:>7.1f}{flag}"
                else:
                    dd = "     --"
                lineas.append(f"  {etq:<5} {rr}  {gg}  {dd}")
        print("\n".join(lineas))
        print("=" * 46)

    # ── Bucle principal ────────────────────────────────────────────────────────
    def run(self, loop_hz=30, print_hz=5):
        rate = rospy.Rate(loop_hz)
        cada = max(1, int(loop_hz / print_hz))
        i = 0
        try:
            while not rospy.is_shutdown() and p.isConnected():
                self._actualizar()
                if i % cada == 0:
                    self._imprimir()
                i += 1
                rate.sleep()
        finally:
            self._running = False
            time.sleep(0.2)
            for ph, _ in self._ports.values():
                ph.closePort()
            print("\nPuertos GELLO cerrados.")


if __name__ == '__main__':
    try:
        VisualizadorFantasma().run(loop_hz=30, print_hz=5)
    except rospy.ROSInterruptException:
        pass