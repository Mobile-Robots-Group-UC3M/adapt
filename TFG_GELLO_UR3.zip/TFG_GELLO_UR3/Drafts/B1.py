from dynamixel_sdk import PortHandler, PacketHandler
import math, time, signal, sys

PORT = "/dev/ttyUSB2"     # brazo motores 8-13 (ajusta si bailó el puerto)
BAUD = 57600

ADDR_OPERATING_MODE   = 11
ADDR_TORQUE_ENABLE    = 64
ADDR_GOAL_CURRENT     = 102
ADDR_PRESENT_POSITION = 132
TICKS = 4096

# ── Joints a compensar: id -> (C, phi_rad, signo) ──
COMP = {
    8:  (40, math.radians(0),   +1),
    9:  (80, math.radians(45),  -1),   # hombro
    10: (40, math.radians(270), +1),   # codo
    11: (9,  math.radians(270), -1),   # wrist_1
}
LIBRES = [8, 12, 13]      # sin compensar, se dejan sueltos

ph = PortHandler(PORT); pk = PacketHandler(2.0)
ph.openPort(); ph.setBaudRate(BAUD)

# Configurar los joints compensados en modo corriente
for mid in COMP:
    pk.write1ByteTxRx(ph, mid, ADDR_TORQUE_ENABLE, 0)
    pk.write1ByteTxRx(ph, mid, ADDR_OPERATING_MODE, 0)
    pk.write1ByteTxRx(ph, mid, ADDR_TORQUE_ENABLE, 1)

# Dejar los libres sueltos (torque off)
for mid in LIBRES:
    pk.write1ByteTxRx(ph, mid, ADDR_TORQUE_ENABLE, 0)

def set_corriente(mid, val):
    val = max(-200, min(200, int(val)))
    pk.write2ByteTxRx(ph, mid, ADDR_GOAL_CURRENT, val & 0xFFFF)

def leer_angulo(mid):
    pos, res, err = pk.read4ByteTxRx(ph, mid, ADDR_PRESENT_POSITION)
    if res != 0 or err != 0:
        return None
    return (pos % TICKS) / TICKS * 2 * math.pi

def apagar(*_):
    for mid in COMP:
        set_corriente(mid, 0)
    time.sleep(0.05)
    for mid in COMP:
        pk.write1ByteTxRx(ph, mid, ADDR_TORQUE_ENABLE, 0)
    time.sleep(0.1)
    ph.closePort()
    print("\nApagado.")
    sys.exit(0)

signal.signal(signal.SIGINT,  apagar)
signal.signal(signal.SIGTERM, apagar)

while True:
    linea = []
    for mid, (C, phi, signo) in COMP.items():
        theta = leer_angulo(mid)
        if theta is None:          # lectura fallida: no empujes a ciegas
            set_corriente(mid, 0)
            linea.append(f"J{mid}: --- ")
            continue
        corriente = signo * C * math.cos(theta - phi)
        set_corriente(mid, corriente)
        linea.append(f"J{mid}: θ={math.degrees(theta):6.1f}° i={corriente:6.1f}")
    print("   ".join(linea))
    time.sleep(0.02)