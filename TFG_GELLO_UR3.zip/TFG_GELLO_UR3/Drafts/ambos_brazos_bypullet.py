import math
import time
import threading
import pybullet as p
import pybullet_data
from dynamixel_sdk import PortHandler, PacketHandler


# ── Configuración brazo 1 (IZQUIERDA) ─────────────────────────────────────────────────────
PORT_1      = "/dev/ttyUSB1"
MOTOR_IDS_1 = [1, 2, 3, 4, 5, 6]
SIGNS_1     = [1, 1, -1, 1, 1, 1]
OFFSETS_1 = [-3.212, -4.746 - 0.7854, 2.65, -3.158, -3.177, -1.466]

# ── Configuración brazo 2 (DERECHA) ─────────────────────────────────────────────────────
PORT_2      = "/dev/ttyUSB0"
MOTOR_IDS_2 = [8, 9, 10, 11, 12, 13]
SIGNS_2     = [1, 1, -1, 1, 1, 1]
OFFSETS_2   = [-3.212, -8.6736, 3.173, -0.889, -3.177, 1.466]

# ── Configuración común ───────────────────────────────────────────────────────
BAUDRATE  = 57600
PROTOCOL  = 2.0
URDF_PATH = "/home/alumnos/tfg-laura/robotics-toolbox/xacro_generated/ur_description/urdf/ur3.urdf"

ADDR_PRESENT_POSITION = 132
TICKS_POR_VUELTA      = 4096

# ── Conversión ────────────────────────────────────────────────────────────────
def ticks_a_rad(ticks):
    ticks_norm = ticks % TICKS_POR_VUELTA
    return (ticks_norm / TICKS_POR_VUELTA) * 2 * math.pi
def normalizar_grados(deg):
    return ((deg + 180) % 360) - 180

def aplicar_transformacion(ticks_list, signs, offsets):
    return [signs[i] * ticks_a_rad(t) + offsets[i]
            for i, t in enumerate(ticks_list)]

# ── Estado compartido ─────────────────────────────────────────────────────────
q_brazo1 = [0.0] * 6
q_brazo2 = [0.0] * 6
lock_q1  = threading.Lock()
lock_q2  = threading.Lock()
running  = True

# ── Inicializar comunicación Dynamixel ────────────────────────────────────────
def init_puerto(port):
    ph = PortHandler(port)
    pk = PacketHandler(PROTOCOL)
    if not ph.openPort():
        raise IOError(f"No se pudo abrir {port}")
    if not ph.setBaudRate(BAUDRATE):
        raise IOError(f"No se pudo configurar baudrate en {port}")
    print(f"✓ Conectado a {port}")
    return ph, pk

port_handler_1, packet_handler_1 = init_puerto(PORT_1)
port_handler_2, packet_handler_2 = init_puerto(PORT_2)

lock_port1 = threading.Lock()
lock_port2 = threading.Lock()

def leer_posicion(motor_id, port_handler, packet_handler, lock_port):
    try:
        with lock_port:
            pos, result, error = packet_handler.read4ByteTxRx(
                port_handler, motor_id, ADDR_PRESENT_POSITION)
        if result != 0 or error != 0:
            return None
        return pos
    except Exception:
        return None

# ── Hilos de lectura ──────────────────────────────────────────────────────────
def hilo_lectura(motor_ids, signs, offsets, port_handler, packet_handler,
                 lock_port, lock_q, q_ref, label):
    while running:
        try:
            ticks_list = []
            hay_error  = False
            for motor_id in motor_ids:
                pos = leer_posicion(motor_id, port_handler, packet_handler, lock_port)
                if pos is None:
                    hay_error = True
                    break
                ticks_list.append(pos)

            if not hay_error:
                q_nuevo = aplicar_transformacion(ticks_list, signs, offsets)
                with lock_q:
                    q_ref[:] = q_nuevo
        except Exception:
            pass

threading.Thread(
    target=hilo_lectura,
    args=(MOTOR_IDS_1, SIGNS_1, OFFSETS_1,
          port_handler_1, packet_handler_1,
          lock_port1, lock_q1, q_brazo1, "B1"),
    daemon=True
).start()

threading.Thread(
    target=hilo_lectura,
    args=(MOTOR_IDS_2, SIGNS_2, OFFSETS_2,
          port_handler_2, packet_handler_2,
          lock_port2, lock_q2, q_brazo2, "B2"),
    daemon=True
).start()

# ── Inicializar PyBullet ──────────────────────────────────────────────────────
p.connect(p.GUI)
p.setAdditionalSearchPath(pybullet_data.getDataPath())
p.setGravity(0, 0, 0)
p.resetDebugVisualizerCamera(
    cameraDistance=1.8,
    cameraYaw=45,
    cameraPitch=-30,
    cameraTargetPosition=[0, 0, 0.3]
)

p.loadURDF("plane.urdf")

# Cargar los dos robots separados en el espacio
# Separación de 20cm (±0.1m cada uno), altura de 60cm, rotados 180° en Y
rot_180y = p.getQuaternionFromEuler([0, math.pi, 0])
rot_180y_180z = p.getQuaternionFromEuler([0, math.pi, math.pi])

robot_id_1 = p.loadURDF(URDF_PATH, 
                         basePosition=[-0.1, 0, 0.8],
                         baseOrientation=rot_180y,
                         useFixedBase=True)
robot_id_2 = p.loadURDF(URDF_PATH, 
                         basePosition=[ 0.1, 0, 0.8],
                         baseOrientation=rot_180y_180z,
                         useFixedBase=True)

def get_joints_moviles(robot_id):
    joints = []
    for i in range(p.getNumJoints(robot_id)):
        info = p.getJointInfo(robot_id, i)
        if info[2] == p.JOINT_REVOLUTE:
            joints.append(i)
    return joints

joints_1 = get_joints_moviles(robot_id_1)
joints_2 = get_joints_moviles(robot_id_2)

print(f"✓ Brazo 1 cargado. Joints: {joints_1}")
print(f"✓ Brazo 2 cargado. Joints: {joints_2}")
print("  Mueve los GELLO para ver los robots moverse.")
print("  Cierra la ventana de PyBullet para detener.\n")

# Aplicar posición inicial
time.sleep(0.5)
with lock_q1:
    for i, j in enumerate(joints_1[:6]):
        p.resetJointState(robot_id_1, j, q_brazo1[i])
with lock_q2:
    for i, j in enumerate(joints_2[:6]):
        p.resetJointState(robot_id_2, j, q_brazo2[i])

# ── Bucle principal ───────────────────────────────────────────────────────────
try:
    while p.isConnected():
        with lock_q1:
            q1 = list(q_brazo1)
        with lock_q2:
            q2 = list(q_brazo2)

        for i, j in enumerate(joints_1[:6]):
            p.resetJointState(robot_id_1, j, q1[i])
        for i, j in enumerate(joints_2[:6]):
            p.resetJointState(robot_id_2, j, q2[i])

        # Imprimir ambos brazos en consola
        b1 = "  ".join(f"J{i+1}:{normalizar_grados(math.degrees(q1[i])):>6.1f}°" for i in range(6))
        b2 = "  ".join(f"J{i+1}:{normalizar_grados(math.degrees(q2[i])):>6.1f}°" for i in range(6))
        print(f"B1: {b1}", end="\n")
        #print(f"B2: {b2}", end="\033[2A")  # sube 2 líneas para sobreescribir
        print(f"B2: {b2}", end="\n")

        p.stepSimulation()
        time.sleep(0.05)

except Exception as e:
    print(f"\nError: {e}")

finally:
    running = False
    time.sleep(0.2)
    port_handler_1.closePort()
    port_handler_2.closePort()
    print("\n\nPuertos cerrados.")