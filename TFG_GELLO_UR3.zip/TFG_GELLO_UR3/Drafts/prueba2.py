from dynamixel_sdk import PortHandler, PacketHandler
import time, signal, sys

PORT = "/dev/ttyUSB2"     # brazo motores 8-13 (ajusta si bailó el puerto)
DXL_ID = 11               # codo
BAUD = 57600

ADDR_OPERATING_MODE  = 11
ADDR_TORQUE_ENABLE   = 64
ADDR_GOAL_CURRENT    = 102

ph = PortHandler(PORT); pk = PacketHandler(2.0)
ph.openPort(); ph.setBaudRate(BAUD)

pk.write1ByteTxRx(ph, DXL_ID, ADDR_TORQUE_ENABLE, 0)
pk.write1ByteTxRx(ph, DXL_ID, ADDR_OPERATING_MODE, 0)
pk.write1ByteTxRx(ph, DXL_ID, ADDR_TORQUE_ENABLE, 1)

def set_corriente(val):
    pk.write2ByteTxRx(ph, DXL_ID, ADDR_GOAL_CURRENT, val & 0xFFFF)

def apagar(*_):
    set_corriente(0)
    time.sleep(0.05)
    pk.write1ByteTxRx(ph, DXL_ID, ADDR_TORQUE_ENABLE, 0)
    time.sleep(0.1)
    ph.closePort()
    print("\nApagado.")
    sys.exit(0)

signal.signal(signal.SIGINT,  apagar)
signal.signal(signal.SIGTERM, apagar)

corriente = 0
PASO = -3            # codo: empuje negativo (lo viste en las pruebas)
TOPE = -200          # red de seguridad
try:
    while corriente > TOPE:
        set_corriente(corriente)
        print(f"Corriente pedida: {corriente}")
        time.sleep(0.8)
        corriente += PASO
    apagar()
except KeyboardInterrupt:
    apagar()