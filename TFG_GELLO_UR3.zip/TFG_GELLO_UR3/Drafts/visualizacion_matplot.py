import math
import threading
import time
import numpy as np
import roboticstoolbox as rtb
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from dynamixel_sdk import PortHandler, PacketHandler

# ── Configuración ─────────────────────────────────────────────────────────────
PORT      = "/dev/ttyUSB0" #! Si no se conecat hay que hacer el 'sudo chmod 666 /dev/ttyUSB0'
BAUDRATE  = 57600
PROTOCOL  = 2.0
#MOTOR_IDS = [1, 2, 3, 4, 5, 6]
MOTOR_IDS = [8, 9, 10, 11, 12, 13]

ADDR_PRESENT_POSITION = 132
TICKS_POR_VUELTA      = 4096

JOINT_SIGNS   = [1, 1, -1, 1, 1, 1]
#JOINT_OFFSETS = [-3.212, -4.746, 3.173, -3.158, -3.177, 1.466]
JOINT_OFFSETS = [-6.2262, -3.3671, 3.1002, -1.6222, -3.2817, -4.6493]


# ── Conversión ────────────────────────────────────────────────────────────────
def ticks_a_rad(ticks):
    return (ticks / TICKS_POR_VUELTA) * 2 * math.pi

def aplicar_transformacion(ticks_list):
    return [JOINT_SIGNS[i] * ticks_a_rad(t) + JOINT_OFFSETS[i]
            for i, t in enumerate(ticks_list)]

# ── Estado compartido ─────────────────────────────────────────────────────────
q_actual  = [0.0] * 6
lock_q    = threading.Lock()
lock_port = threading.Lock()
running   = True

# ── Inicializar comunicación Dynamixel ────────────────────────────────────────
port_handler   = PortHandler(PORT)
packet_handler = PacketHandler(PROTOCOL)

if not port_handler.openPort():
    raise IOError(f"No se pudo abrir {PORT}. ¿Está el U2D2 conectado?")
if not port_handler.setBaudRate(BAUDRATE):
    raise IOError(f"No se pudo configurar el baudrate {BAUDRATE}.")

print(f"✓ Conectado a {PORT}")

def leer_posicion(motor_id):
    try:
        with lock_port:
            pos, result, error = packet_handler.read4ByteTxRx(
                port_handler, motor_id, ADDR_PRESENT_POSITION)
        if result != 0 or error != 0:
            return None
        return pos
    except Exception:
        return None

# ── Hilo de lectura ───────────────────────────────────────────────────────────
def hilo_lectura():
    global q_actual
    while running:
        try:
            ticks_list = []
            hay_error  = False
            for motor_id in MOTOR_IDS:
                pos = leer_posicion(motor_id)
                if pos is None:
                    hay_error = True
                    break
                ticks_list.append(pos)

            if not hay_error:
                q_nuevo = aplicar_transformacion(ticks_list)
                with lock_q:
                    q_actual = q_nuevo
                print("  ".join(
                    f"J{i+1}:{math.degrees(q_actual[i]):>7.1f}°"
                    for i in range(6)
                ), end="\r")
        except Exception:
            pass

threading.Thread(target=hilo_lectura, daemon=True).start()

# ── Visualización con entorno pyplot de la toolbox ────────────────────────────
robot = rtb.models.UR3()
robot.q = robot.qz

# Lanza el entorno pyplot de la toolbox (no block para que no congele)
env = robot.plot(robot.qz, backend='pyplot', block=False, limits=[0.6, 0.6, -0.6, 0.6, 0, 0.6])


robot = rtb.models.UR3()

# Leer posición inicial real de los motores
ticks_iniciales = []
for motor_id in MOTOR_IDS:
    pos = leer_posicion(motor_id)
    ticks_iniciales.append(pos if pos is not None else 2048)  # 2048 = centro si falla

q_inicial = aplicar_transformacion(ticks_iniciales)
with lock_q:
    q_actual = q_inicial

robot.q = q_inicial
env = robot.plot(q_inicial, backend='pyplot', block=False)



print("✓ Visualización iniciada. Mueve el GELLO para ver el robot moverse.")
print("  Cierra la ventana para detener.\n")

# Bucle principal: actualiza manualmente en vez de usar FuncAnimation
try:
    while plt.get_fignums():  # mientras la ventana esté abierta
        with lock_q:
            q = list(q_actual)
        robot.q = q
        env.step(0.05)
except Exception:
    pass

running = False
time.sleep(0.2)
port_handler.closePort()
print("Puerto cerrado.")