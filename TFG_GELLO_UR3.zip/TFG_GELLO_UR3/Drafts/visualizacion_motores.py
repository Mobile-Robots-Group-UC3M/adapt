import time
import math
import roboticstoolbox as rtb
import swift

from dynamixel_sdk import PortHandler, PacketHandler

# ── Configuración ─────────────────────────────────────────────────────────────
PORT      = "COM5"
BAUDRATE  = 57600
PROTOCOL  = 2.0
MOTOR_IDS = [1, 2, 3, 4, 5, 6]   # motores articulares (el 7 es el gripper, no va al modelo)

ADDR_PRESENT_POSITION = 132
TICKS_POR_VUELTA      = 4096

# Joint signs del UR: corrigen ejes invertidos entre GELLO y UR3
# Ajusta estos valores después de la calibración si alguna articulación va al revés
JOINT_SIGNS = [1, 1, -1, 1, 1, 1]

# Offsets (en radianes): diferencia entre el cero del Dynamixel y el cero del UR3
# De momento están a 0 — los calcularás con el script de calibración de GELLO
JOINT_OFFSETS = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0]

# ── Conversión ticks → radianes ───────────────────────────────────────────────
def ticks_a_rad(ticks):
    """Convierte ticks del encoder (0-4095) a radianes (0 - 2π)."""
    #si alcanzamos límite no leemos
    return (ticks / TICKS_POR_VUELTA) * 2 * math.pi

def ticks_a_grados(ticks):
    return round(math.degrees(ticks_a_rad(ticks)), 2)

def aplicar_transformacion(ticks_list):
    """Convierte lista de ticks a ángulos articulares del UR3 en radianes."""
    q = []
    for i, ticks in enumerate(ticks_list):
        rad = ticks_a_rad(ticks)
        rad_corregido = JOINT_SIGNS[i] * rad + JOINT_OFFSETS[i]
        q.append(rad_corregido)
    return q

# ── Inicializar comunicación Dynamixel ────────────────────────────────────────
port_handler   = PortHandler(PORT)
packet_handler = PacketHandler(PROTOCOL)

if not port_handler.openPort():
    raise IOError(f"No se pudo abrir el puerto {PORT}. ¿Está el U2D2 conectado?")

if not port_handler.setBaudRate(BAUDRATE):
    raise IOError(f"No se pudo configurar el baudrate {BAUDRATE}.")

print(f"✓ Conectado a {PORT}")

# ── Inicializar visualizador Swift ────────────────────────────────────────────
env   = swift.Swift()
env.launch(realtime=True)   # abre el navegador automáticamente

robot = rtb.models.UR3()
robot.q = robot.qz          # posición inicial: todos los ángulos a cero
env.add(robot)

print("✓ Visualizador Swift lanzado en el navegador")
print("  Mueve el GELLO para ver el robot moverse en tiempo real.")
print("  Pulsa Ctrl+C para detener.\n")

# ── Función de lectura de un motor ────────────────────────────────────────────
def leer_posicion(motor_id):
    pos, result, error = packet_handler.read4ByteTxRx(
        port_handler, motor_id, ADDR_PRESENT_POSITION
    )
    if result != 0 or error != 0:
        return None
    return pos

# ── Bucle principal ───────────────────────────────────────────────────────────
try:
    while True:
        ticks_list = []
        hay_error  = False

        for motor_id in MOTOR_IDS:
            pos = leer_posicion(motor_id)
            if pos is None:
                print(f"  ⚠ Error leyendo motor {motor_id}, saltando ciclo...")
                hay_error = True
                break
            ticks_list.append(pos)

        if hay_error:
            time.sleep(0.1)
            continue

        # Convertir a ángulos articulares
        q = aplicar_transformacion(ticks_list)

        # Actualizar visualización
        robot.q = q
        env.step(0)   # refresca el visualizador sin avanzar simulación

        # Imprimir estado en consola
        print("  ".join(
            f"J{i+1}: {ticks_a_grados(t):>7}°"
            for i, t in enumerate(ticks_list)
        ), end="\r")

        # Leer también el gripper (motor 7) solo para mostrarlo en consola
        gripper_ticks = leer_posicion(7)
        if gripper_ticks is not None:
            print(f"  Gripper: {ticks_a_grados(gripper_ticks):>7}°", end="\r")

        time.sleep(0.05)   # ~20 lecturas por segundo

except KeyboardInterrupt:
    print("\n\nDetenido por el usuario.")

finally:
    port_handler.closePort()
    print("Puerto cerrado.")